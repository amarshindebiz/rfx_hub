"""
RFX_FocusPicker - browser.py
============================
Main PySide6 UI window and About dialog.
All Maya attribute writes delegate to core.py.

Requires: Maya 2025+, PySide6, shiboken6, Arnold for Maya (MtoA)
"""
from __future__ import annotations

# ---------------------------------------------------------------------------
# Plugin constants
# ---------------------------------------------------------------------------
PLUGIN_NAME     = "RFX FocusPicker"
PLUGIN_VERSION  = "1.0"
STUDIO_NAME     = "Reimagine Fx"
AUTHOR_NAME     = "Amar Shinde"
WEBSITE         = "www.reimaginefx.com"
EMAIL           = "reimaginefx@gmail.com"
DISCORD         = "Reimagine Fx Community"
COPYRIGHT_YEAR  = "2026"
DESCRIPTION     = (
    "A one-click viewport focus tool for Arnold cameras in Maya. "
    "Ray-cast any surface to set focus distance instantly, with live "
    "controls for DOF, aperture and camera switching."
)

# ---------------------------------------------------------------------------
# Color palette
# ---------------------------------------------------------------------------
C_ACCENT        = "#2FA4D7"
C_ACCENT_HOVER  = "#4DC0EF"
C_ACCENT_DIM    = "#1A6080"
C_BG_WINDOW     = "#1E1E1E"
C_BG_HEADER     = "#161616"
C_BG_BODY       = "#1A1A1A"
C_BG_SECTION    = "#252525"
C_BG_INPUT      = "#2A2A2A"
C_BG_INPUT_FOC  = "#303030"
C_BG_BTN        = "#2E2E2E"
C_BG_BTN_HOV    = "#3A3A3A"
C_BG_BTN_PRI    = "#1D6E8F"
C_BG_BTN_PRI_H  = "#2FA4D7"
C_BORDER        = "#333333"
C_TEXT_PRI      = "#E8E8E8"
C_TEXT_SEC      = "#888888"
C_TEXT_DIM      = "#555555"
C_TEXT_HEADER   = "#FFFFFF"
C_TEXT_ACCENT   = "#2FA4D7"
C_STATUS_OK     = "#4EC94E"
C_STATUS_WARN   = "#E8A040"
C_STATUS_ERR    = "#E05050"
C_PICK_BTN      = "#1D6E8F"
C_PICK_BTN_HOV  = "#2FA4D7"

# ---------------------------------------------------------------------------
# Imports
# ---------------------------------------------------------------------------
import os
import sys
import logging

import maya.cmds as cmds


from PySide6 import QtCore, QtGui, QtWidgets
import shiboken6

try:
    import maya.OpenMayaUI as omui
    _MUI_OK = True
except ImportError:
    _MUI_OK = False

# ---------------------------------------------------------------------------
# Logger
# ---------------------------------------------------------------------------
log = logging.getLogger(__name__)
if not log.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("[%(name)s] %(levelname)s: %(message)s"))
    log.addHandler(_h)
log.setLevel(logging.INFO)


# ---------------------------------------------------------------------------
# Icon path helper -- uses __file__ (safe here, this is an imported module)
# ---------------------------------------------------------------------------

def _get_icons_dir():
    """Return absolute path to the icons/ folder inside the plugin package."""
    this_file = os.path.abspath(__file__)
    pkg_dir   = os.path.dirname(this_file)
    return os.path.join(pkg_dir, "icons")


def _maya_main_window():
    if not _MUI_OK:
        return None
    try:
        ptr = omui.MQtUtil.mainWindow()
        if ptr is None:
            return None
        return shiboken6.wrapInstance(int(ptr), QtWidgets.QWidget)
    except Exception:
        return None


# ===========================================================================
# Global stylesheet
# ===========================================================================

_STYLESHEET = (
    "QWidget {"
    "  background-color: " + C_BG_WINDOW + ";"
    "  color: " + C_TEXT_PRI + ";"
    "  font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif;"
    "  font-size: 11px; border: none; outline: none;"
    "}"
    "QLabel { background: transparent; color: " + C_TEXT_SEC + "; }"
    "QComboBox {"
    "  background-color: " + C_BG_INPUT + "; color: " + C_TEXT_PRI + ";"
    "  border: 1px solid " + C_BORDER + "; border-radius: 3px;"
    "  padding: 2px 6px; min-height: 22px;"
    "}"
    "QComboBox:focus { border-color: " + C_ACCENT + "; background-color: " + C_BG_INPUT_FOC + "; }"
    "QComboBox::drop-down { border: none; width: 20px; }"
    "QComboBox QAbstractItemView {"
    "  background-color: " + C_BG_SECTION + "; color: " + C_TEXT_PRI + ";"
    "  selection-background-color: " + C_ACCENT_DIM + "; border: 1px solid " + C_BORDER + ";"
    "}"
    "QDoubleSpinBox {"
    "  background-color: " + C_BG_INPUT + "; color: " + C_TEXT_PRI + ";"
    "  border: 1px solid " + C_BORDER + "; border-radius: 3px;"
    "  padding: 2px 6px; min-height: 22px;"
    "}"
    "QDoubleSpinBox:focus { border-color: " + C_ACCENT + "; background-color: " + C_BG_INPUT_FOC + "; }"
    "QCheckBox { color: " + C_TEXT_PRI + "; spacing: 6px; }"
    "QCheckBox::indicator {"
    "  width: 14px; height: 14px; border: 1px solid " + C_BORDER + ";"
    "  border-radius: 2px; background-color: " + C_BG_INPUT + ";"
    "}"
    "QCheckBox::indicator:checked { background-color: " + C_ACCENT + "; border-color: " + C_ACCENT + "; }"
    "QCheckBox::indicator:hover { border-color: " + C_ACCENT + "; }"
    "QScrollBar:vertical { background: " + C_BG_WINDOW + "; width: 8px; margin: 0; }"
    "QScrollBar::handle:vertical { background: " + C_BORDER + "; border-radius: 4px; min-height: 20px; }"
    "QScrollBar::handle:vertical:hover { background: " + C_ACCENT_DIM + "; }"
    "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }"
    "QToolTip {"
    "  background-color: " + C_BG_SECTION + "; color: " + C_TEXT_PRI + ";"
    "  border: 1px solid " + C_ACCENT_DIM + "; padding: 4px 8px; border-radius: 3px;"
    "}"
)


# ===========================================================================
# UI helpers
# ===========================================================================

def _label(text, color=None, bold=False, size=None, align=None):
    lbl = QtWidgets.QLabel(text)
    parts = ["QLabel { background: transparent; color: " + (color or C_TEXT_SEC) + ";"]
    if bold:
        parts.append("font-weight: bold;")
    if size:
        parts.append("font-size: " + str(size) + "px;")
    parts.append("}")
    lbl.setStyleSheet(" ".join(parts))
    if align is not None:
        lbl.setAlignment(align)
    return lbl


def _h_line():
    line = QtWidgets.QFrame()
    line.setFrameShape(QtWidgets.QFrame.HLine)
    line.setFixedHeight(1)
    line.setStyleSheet("background-color: " + C_BORDER + "; border: none;")
    return line


# ===========================================================================
# Section header band
# ===========================================================================

class _SectionHeader(QtWidgets.QWidget):
    """
    Full-width dark band with a 3-px cyan left bar and uppercase label.
    Bar is a dedicated child widget so it never overlaps the text.
    """

    def __init__(self, title, parent=None):
        super(_SectionHeader, self).__init__(parent)
        self.setFixedHeight(22)
        self.setStyleSheet("background-color: " + C_BG_SECTION + ";")

        outer = QtWidgets.QHBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        bar = QtWidgets.QWidget()
        bar.setFixedSize(3, 22)
        bar.setStyleSheet("background-color: " + C_ACCENT + "; border: none;")
        outer.addWidget(bar)

        gap = QtWidgets.QWidget()
        gap.setFixedWidth(8)
        gap.setStyleSheet("background: transparent;")
        outer.addWidget(gap)

        lbl = _label(title.upper(), color=C_TEXT_ACCENT, bold=True, size=10)
        outer.addWidget(lbl)
        outer.addStretch()


# ===========================================================================
# Maya drag spinbox
# ===========================================================================

class MayaDragSpinBox(QtWidgets.QDoubleSpinBox):
    """
    QDoubleSpinBox with Maya Channel Box drag behaviour.
      - Ctrl + MMB drag on the field to scrub
      - LMB drag on linked label to scrub
      - Shift = fast, Alt = precise
    """

    def __init__(self, value=0.0, min_val=0.0, max_val=99999.0,
                 step=0.1, decimals=4, width=160, parent=None):
        super(MayaDragSpinBox, self).__init__(parent)
        # Force C locale so decimal separator is always a dot,
        # not a comma -- Qt inherits the Windows system locale otherwise.
        self.setLocale(QtCore.QLocale(QtCore.QLocale.C))
        self.setDecimals(decimals)
        self.setMinimum(min_val)
        self.setMaximum(max_val)
        self.setSingleStep(step)
        self.setValue(value)
        self.setMinimumWidth(width)
        self.setButtonSymbols(QtWidgets.QAbstractSpinBox.NoButtons)

        self._base_step      = step
        self._is_dragging    = False
        self._drag_start_x   = 0
        self._drag_start_val = 0.0
        self._app_filter     = None

        self._ss_normal = (
            "QDoubleSpinBox {"
            "  background-color: " + C_BG_INPUT + ";"
            "  color: " + C_TEXT_PRI + ";"
            "  border: 1px solid " + C_BORDER + ";"
            "  border-radius: 3px;"
            "  padding: 2px 6px;"
            "  min-height: 22px;"
            "}"
            "QDoubleSpinBox:focus {"
            "  border-color: " + C_ACCENT + ";"
            "  background-color: " + C_BG_INPUT_FOC + ";"
            "}"
        )
        self._ss_drag = (
            "QDoubleSpinBox {"
            "  background-color: " + C_BG_INPUT + ";"
            "  color: " + C_TEXT_PRI + ";"
            "  border: 1px solid " + C_ACCENT + ";"
            "  border-radius: 3px;"
            "  padding: 2px 6px;"
            "  min-height: 22px;"
            "}"
        )
        self.setStyleSheet(self._ss_normal)
        self.lineEdit().installEventFilter(self)

    class _AppFilter(QtCore.QObject):
        def __init__(self, owner):
            super(MayaDragSpinBox._AppFilter, self).__init__()
            self._owner = owner

        def eventFilter(self, obj, event):
            t = event.type()
            if t == QtCore.QEvent.MouseMove:
                if self._owner._is_dragging:
                    self._owner._update_drag(
                        event.globalPos().x(), event.modifiers())
                    return False
            elif t == QtCore.QEvent.MouseButtonRelease:
                if (self._owner._is_dragging and
                        event.button() == QtCore.Qt.MiddleButton):
                    self._owner._end_drag()
                    return False
            return False

    def set_drag_label(self, label):
        label.setCursor(QtCore.Qt.SizeHorCursor)
        label.setToolTip("LMB drag  |  Ctrl+MMB drag on field")
        label.installEventFilter(self)
        label.setMouseTracking(True)

    def _start_drag(self, global_x):
        self._is_dragging    = True
        self._drag_start_x   = global_x
        self._drag_start_val = self.value()
        self.setStyleSheet(self._ss_drag)
        QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.SizeHorCursor)
        self._app_filter = MayaDragSpinBox._AppFilter(self)
        QtWidgets.QApplication.instance().installEventFilter(self._app_filter)

    def _update_drag(self, global_x, modifiers):
        delta_px = global_x - self._drag_start_x
        if modifiers & QtCore.Qt.ShiftModifier:
            mult = 1.0
        elif modifiers & QtCore.Qt.AltModifier:
            mult = 0.001
        else:
            mult = 0.01
        val = self._drag_start_val + delta_px * self._base_step * mult
        val = max(self.minimum(), min(self.maximum(), val))
        self.setValue(val)

    def _end_drag(self):
        self._is_dragging = False
        self.setStyleSheet(self._ss_normal)
        QtWidgets.QApplication.restoreOverrideCursor()
        if self._app_filter is not None:
            QtWidgets.QApplication.instance().removeEventFilter(self._app_filter)
            self._app_filter = None

    def mousePressEvent(self, event):
        super(MayaDragSpinBox, self).mousePressEvent(event)

    def mouseMoveEvent(self, event):
        super(MayaDragSpinBox, self).mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        super(MayaDragSpinBox, self).mouseReleaseEvent(event)

    def eventFilter(self, obj, event):
        t = event.type()
        is_le = (obj is self.lineEdit())

        if t == QtCore.QEvent.MouseButtonPress:
            if is_le:
                if (event.button() == QtCore.Qt.MiddleButton and
                        event.modifiers() & QtCore.Qt.ControlModifier):
                    self._start_drag(event.globalPos().x())
                    return True
            else:
                if event.button() == QtCore.Qt.LeftButton:
                    self._start_drag(event.globalPos().x())
                    return True
        elif t == QtCore.QEvent.MouseMove:
            if self._is_dragging:
                self._update_drag(event.globalPos().x(), event.modifiers())
                return True
        elif t == QtCore.QEvent.MouseButtonRelease:
            if self._is_dragging:
                if ((is_le and event.button() == QtCore.Qt.MiddleButton) or
                        (not is_le and event.button() == QtCore.Qt.LeftButton)):
                    self._end_drag()
                    return True

        return super(MayaDragSpinBox, self).eventFilter(obj, event)


# ===========================================================================
# About dialog
# ===========================================================================

class AboutDialog(QtWidgets.QDialog):

    def __init__(self, parent=None):
        super(AboutDialog, self).__init__(parent)
        self.setWindowTitle("About " + PLUGIN_NAME)
        self.setFixedSize(400, 420)
        self.setWindowFlags(
            QtCore.Qt.Dialog |
            QtCore.Qt.WindowCloseButtonHint |
            QtCore.Qt.MSWindowsFixedSizeDialogHint
        )
        self.setStyleSheet(_STYLESHEET)
        self._build()

    def _build(self):
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Header
        header = QtWidgets.QWidget()
        header.setFixedHeight(90)
        header.setStyleSheet(
            "background-color: " + C_BG_HEADER + ";"
        )
        hl = QtWidgets.QVBoxLayout(header)
        hl.setContentsMargins(24, 14, 24, 14)
        hl.setSpacing(4)

        studio_h = _label(STUDIO_NAME, color=C_ACCENT, bold=True, size=20)
        studio_h.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        hl.addWidget(studio_h)

        plugin_h = _label(
            PLUGIN_NAME + "   v" + PLUGIN_VERSION,
            color=C_TEXT_HEADER, size=11)
        plugin_h.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        hl.addWidget(plugin_h)

        root.addWidget(header)

        # Body
        body = QtWidgets.QWidget()
        body.setStyleSheet("background-color: " + C_BG_WINDOW + ";")
        bl = QtWidgets.QVBoxLayout(body)
        bl.setContentsMargins(24, 20, 24, 20)
        bl.setSpacing(14)

        desc = QtWidgets.QLabel(DESCRIPTION)
        desc.setWordWrap(True)
        desc.setStyleSheet(
            "QLabel { color: " + C_TEXT_SEC + "; font-size: 11px;"
            " background: transparent; }")
        bl.addWidget(desc)

        grid_w = QtWidgets.QWidget()
        grid_w.setStyleSheet("background: transparent;")
        grid = QtWidgets.QGridLayout(grid_w)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(16)
        grid.setVerticalSpacing(10)
        grid.setColumnStretch(1, 1)

        rows = [
            ("Author",  AUTHOR_NAME),
            ("Studio",  STUDIO_NAME),
            ("Website", WEBSITE),
            ("Email",   EMAIL),
            ("Discord", DISCORD),
            ("Version", PLUGIN_VERSION),
        ]
        for i, (key, val) in enumerate(rows):
            key_lbl = _label(key + ":", color=C_TEXT_DIM, size=10)
            key_lbl.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
            val_lbl = QtWidgets.QLabel(val)
            val_lbl.setStyleSheet(
                "QLabel { color: " + C_TEXT_PRI + "; background: transparent; }")
            val_lbl.setTextInteractionFlags(
                QtCore.Qt.TextSelectableByMouse |
                QtCore.Qt.TextSelectableByKeyboard)
            val_lbl.setCursor(QtCore.Qt.IBeamCursor)
            grid.addWidget(key_lbl, i, 0)
            grid.addWidget(val_lbl, i, 1)

        bl.addWidget(grid_w)
        bl.addStretch()

        copy_lbl = _label(
            "Copyright " + COPYRIGHT_YEAR + " " + STUDIO_NAME + ". All rights reserved.",
            color=C_TEXT_DIM, size=10)
        copy_lbl.setAlignment(QtCore.Qt.AlignCenter)
        bl.addWidget(copy_lbl)
        root.addWidget(body)

        # Footer
        footer = QtWidgets.QWidget()
        footer.setFixedHeight(50)
        footer.setStyleSheet(
            "background-color: " + C_BG_HEADER + ";"
            "border-top: 1px solid " + C_BORDER + ";"
        )
        fl = QtWidgets.QHBoxLayout(footer)
        fl.setContentsMargins(16, 8, 16, 8)
        fl.addStretch()

        close_btn = QtWidgets.QPushButton("Close")
        close_btn.setFixedSize(90, 32)
        close_btn.setStyleSheet(
            "QPushButton {"
            "  background-color: " + C_BG_BTN_PRI + ";"
            "  color: " + C_TEXT_HEADER + ";"
            "  border: 1px solid " + C_ACCENT + ";"
            "  border-radius: 4px; font-weight: 600;"
            "}"
            "QPushButton:hover { background-color: " + C_BG_BTN_PRI_H + "; }"
        )
        close_btn.clicked.connect(self.accept)
        fl.addWidget(close_btn)
        root.addWidget(footer)


# ===========================================================================
# Main window
# ===========================================================================

class FocusPickerWindow(QtWidgets.QWidget):

    def __init__(self, parent=None):
        super(FocusPickerWindow, self).__init__(parent)
        self.setWindowTitle(PLUGIN_NAME + "  v" + PLUGIN_VERSION)
        self.setWindowFlags(
            QtCore.Qt.Window |
            QtCore.Qt.WindowCloseButtonHint |
            QtCore.Qt.WindowMinimizeButtonHint
        )
        self.setMinimumWidth(380)
        self.setMaximumWidth(900)
        self.resize(420, 340)
        self.setStyleSheet(_STYLESHEET)

        self._core = None
        self._load_core()
        self._build_ui()
        self._populate_cameras()

    def _load_core(self):
        try:
            from . import core as _core
            self._core = _core
        except ImportError:
            try:
                import core as _core
                self._core = _core
            except ImportError:
                log.error("RFX_FocusPicker: could not import core.py")

    def _build_ui(self):
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self._build_header())
        root.addWidget(self._build_body())
        root.addWidget(self._build_status_bar())

    # ---- Header -------------------------------------------------------

    def _build_header(self):
        hdr = QtWidgets.QWidget()
        hdr.setFixedHeight(80)
        hdr.setStyleSheet(
            "QWidget {"
            "  background-color: #111213;"
            "  border-bottom: 1px solid #252729;"
            "}"
        )
        layout = QtWidgets.QHBoxLayout(hdr)
        layout.setContentsMargins(14, 0, 14, 0)
        layout.setSpacing(14)

        # ---- Icon --------------------------------------------------
        icon_lbl = QtWidgets.QLabel()
        icon_lbl.setFixedSize(52, 52)
        icon_path = os.path.join(_get_icons_dir(), "rfx_focuspicker_icon.png")
        if os.path.isfile(icon_path):
            pix = QtGui.QPixmap(icon_path).scaled(
                52, 52,
                QtCore.Qt.KeepAspectRatio,
                QtCore.Qt.SmoothTransformation
            )
            icon_lbl.setPixmap(pix)
        else:
            icon_lbl.setStyleSheet(
                "QLabel {"
                "  background-color: " + C_ACCENT_DIM + ";"
                "  border: 1px solid " + C_ACCENT + ";"
                "  border-radius: 8px;"
                "}"
            )
        layout.addWidget(icon_lbl)

        # ---- Title block -------------------------------------------
        title_block = QtWidgets.QWidget()
        title_block.setStyleSheet("QWidget { background: transparent; }")
        grid = QtWidgets.QGridLayout(title_block)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setSpacing(0)
        grid.setVerticalSpacing(0)

        title_lbl = QtWidgets.QLabel(PLUGIN_NAME)
        title_lbl.setFixedHeight(26)
        title_lbl.setStyleSheet(
            "QLabel {"
            "  font-size: 22px; font-weight: 700;"
            "  color: #efefef; background: transparent;"
            "  padding: 0px; margin: 0px; border: none;"
            "}"
        )
        grid.addWidget(title_lbl, 0, 0)
        grid.setRowMinimumHeight(0, 26)

        divider = QtWidgets.QWidget()
        divider.setFixedHeight(2)
        divider.setStyleSheet(
            "QWidget { background-color: " + C_ACCENT + ";"
            " padding: 0; margin: 0; }"
        )
        grid.addWidget(divider, 1, 0)
        grid.setRowMinimumHeight(1, 2)

        studio_lbl = QtWidgets.QLabel(STUDIO_NAME)
        studio_lbl.setFixedHeight(20)
        studio_lbl.setStyleSheet(
            "QLabel {"
            "  font-size: 15px; font-weight: 500;"
            "  color: #909090; background: transparent;"
            "  padding: 0px; margin: 0px; border: none;"
            "}"
        )
        grid.addWidget(studio_lbl, 2, 0)
        grid.setRowMinimumHeight(2, 20)

        layout.addWidget(title_block)
        layout.addStretch()

        # ---- About button ------------------------------------------
        about_btn = QtWidgets.QPushButton("About")
        about_btn.setFixedSize(54, 26)
        about_btn.setStyleSheet(
            "QPushButton {"
            "  background-color: transparent;"
            "  color: " + C_TEXT_SEC + ";"
            "  border: 1px solid transparent;"
            "  border-radius: 3px; font-size: 10px;"
            "}"
            "QPushButton:hover {"
            "  color: " + C_ACCENT + ";"
            "  border-color: " + C_ACCENT_DIM + ";"
            "}"
        )
        about_btn.clicked.connect(self._on_about)
        layout.addWidget(about_btn)

        return hdr

    # ---- Body ---------------------------------------------------------

    def _build_body(self):
        body = QtWidgets.QWidget()
        body.setStyleSheet("background-color: " + C_BG_BODY + ";")
        layout = QtWidgets.QVBoxLayout(body)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        layout.addWidget(_SectionHeader("Camera"))
        layout.addWidget(self._build_camera_row())

        layout.addWidget(_SectionHeader("Depth of Field"))
        layout.addWidget(self._build_dof_row())

        layout.addWidget(_SectionHeader("Focus Distance"))
        layout.addWidget(self._build_focus_row())

        layout.addWidget(_SectionHeader("Aperture"))
        layout.addWidget(self._build_aperture_row())

        layout.addStretch()
        return body

    # ---- Camera row ---------------------------------------------------

    def _build_camera_row(self):
        panel = QtWidgets.QWidget()
        panel.setStyleSheet("background-color: " + C_BG_BODY + ";")
        layout = QtWidgets.QHBoxLayout(panel)
        layout.setContentsMargins(14, 8, 14, 8)
        layout.setSpacing(6)

        cam_lbl = _label("Camera")
        cam_lbl.setFixedWidth(72)
        cam_lbl.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        layout.addWidget(cam_lbl)

        self._cam_combo = QtWidgets.QComboBox()
        self._cam_combo.setSizePolicy(
            QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self._cam_combo.currentIndexChanged.connect(self._on_camera_changed)
        layout.addWidget(self._cam_combo)

        # Shared small button style for +, -, Refresh
        _sm_btn_ss = (
            "QPushButton {"
            "  background-color: " + C_BG_BTN + ";"
            "  color: " + C_TEXT_PRI + ";"
            "  border: 1px solid " + C_BORDER + ";"
            "  border-radius: 3px;"
            "  font-size: 14px; font-weight: 600;"
            "  padding: 0px;"
            "}"
            "QPushButton:hover {"
            "  background-color: " + C_BG_BTN_HOV + ";"
            "  border-color: " + C_ACCENT + ";"
            "  color: " + C_ACCENT + ";"
            "}"
        )

        # + button -- create a new Maya camera
        add_btn = QtWidgets.QPushButton("+")
        add_btn.setFixedSize(26, 26)
        add_btn.setToolTip("Create a new camera and add it to the list")
        add_btn.setStyleSheet(_sm_btn_ss)
        add_btn.clicked.connect(self._on_add_camera)
        layout.addWidget(add_btn)

        # - button -- delete selected camera
        del_btn = QtWidgets.QPushButton("-")
        del_btn.setFixedSize(26, 26)
        del_btn.setToolTip("Delete the selected camera from the scene")
        del_btn.setStyleSheet(_sm_btn_ss)
        del_btn.clicked.connect(self._on_remove_camera)
        layout.addWidget(del_btn)

        # Refresh button
        refresh_btn = QtWidgets.QPushButton("Refresh")
        refresh_btn.setFixedWidth(58)
        refresh_btn.setFixedHeight(26)
        refresh_btn.setToolTip("Rebuild camera list from the current scene")
        refresh_btn.setStyleSheet(
            "QPushButton {"
            "  background-color: " + C_BG_BTN + ";"
            "  color: " + C_TEXT_PRI + ";"
            "  border: 1px solid " + C_BORDER + ";"
            "  border-radius: 3px; padding: 2px 4px;"
            "  font-size: 11px;"
            "}"
            "QPushButton:hover {"
            "  background-color: " + C_BG_BTN_HOV + ";"
            "  border-color: " + C_ACCENT + ";"
            "}"
        )
        refresh_btn.clicked.connect(self._on_refresh)
        layout.addWidget(refresh_btn)
        return panel

    # ---- DOF row ------------------------------------------------------

    def _build_dof_row(self):
        panel = QtWidgets.QWidget()
        panel.setStyleSheet("background-color: " + C_BG_BODY + ";")
        layout = QtWidgets.QHBoxLayout(panel)
        layout.setContentsMargins(14, 8, 14, 8)
        layout.setSpacing(8)

        lbl = _label("Enable DOF")
        lbl.setFixedWidth(72)
        lbl.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        layout.addWidget(lbl)

        self._dof_check = QtWidgets.QCheckBox()
        self._dof_check.setToolTip(
            "Toggle aiEnableDOF (falls back to depthOfField)")
        self._dof_check.stateChanged.connect(self._on_dof_changed)
        layout.addWidget(self._dof_check)
        layout.addStretch()
        return panel

    # ---- Focus row ----------------------------------------------------

    def _build_focus_row(self):
        panel = QtWidgets.QWidget()
        panel.setStyleSheet("background-color: " + C_BG_BODY + ";")
        layout = QtWidgets.QHBoxLayout(panel)
        layout.setContentsMargins(14, 8, 14, 8)
        layout.setSpacing(8)

        focus_lbl = _label("Distance")
        focus_lbl.setFixedWidth(72)
        focus_lbl.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        layout.addWidget(focus_lbl)

        self._focus_spin = MayaDragSpinBox(
            value=0.0, min_val=0.0, max_val=99999.0,
            step=0.1, decimals=4, width=146)
        self._focus_spin.setMinimumWidth(100)
        self._focus_spin.setMaximumWidth(99999)
        self._focus_spin.setSizePolicy(
            QtWidgets.QSizePolicy.Expanding,
            QtWidgets.QSizePolicy.Fixed)
        self._focus_spin.set_drag_label(focus_lbl)
        self._focus_spin.setToolTip(
            "aiFocusDistance in scene units\n"
            "Ctrl+MMB drag field  |  LMB drag label")
        self._focus_spin.valueChanged.connect(self._on_focus_changed)
        layout.addWidget(self._focus_spin)

        layout.addStretch()

        self._pick_btn = QtWidgets.QPushButton("Pick Focus")
        self._pick_btn.setMinimumWidth(148)
        self._pick_btn.setFixedHeight(26)
        self._pick_btn.setToolTip(
            "Click any surface to set focus distance\n"
            "Press Esc to cancel  |  Ctrl+MMB drag field  |  LMB drag label")
        self._pick_btn.setStyleSheet(
            "QPushButton {"
            "  background-color: " + C_PICK_BTN + ";"
            "  color: " + C_TEXT_HEADER + ";"
            "  border: 1px solid " + C_ACCENT + ";"
            "  border-radius: 3px; font-weight: 600;"
            "}"
            "QPushButton:hover { background-color: " + C_PICK_BTN_HOV + "; }"
            "QPushButton:pressed { background-color: " + C_ACCENT_DIM + "; }"
        )
        self._pick_btn.clicked.connect(self._on_pick_clicked)
        layout.addWidget(self._pick_btn)
        return panel

    # ---- Aperture row -------------------------------------------------

    def _build_aperture_row(self):
        panel = QtWidgets.QWidget()
        panel.setStyleSheet("background-color: " + C_BG_BODY + ";")
        layout = QtWidgets.QHBoxLayout(panel)
        layout.setContentsMargins(14, 8, 14, 8)
        layout.setSpacing(8)

        aperture_lbl = _label("Size")
        aperture_lbl.setFixedWidth(72)
        aperture_lbl.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        layout.addWidget(aperture_lbl)

        self._aperture_spin = MayaDragSpinBox(
            value=0.1, min_val=0.0, max_val=100.0,
            step=0.01, decimals=4, width=146)
        self._aperture_spin.setMinimumWidth(100)
        self._aperture_spin.setMaximumWidth(99999)
        self._aperture_spin.setSizePolicy(
            QtWidgets.QSizePolicy.Expanding,
            QtWidgets.QSizePolicy.Fixed)
        self._aperture_spin.set_drag_label(aperture_lbl)
        self._aperture_spin.setToolTip(
            "aiApertureSize -- controls bokeh blur radius\n"
            "Ctrl+MMB drag field  |  LMB drag label")
        self._aperture_spin.valueChanged.connect(self._on_aperture_changed)
        layout.addWidget(self._aperture_spin)

        bokeh_lbl = _label("bokeh radius", color=C_TEXT_DIM, size=10)
        layout.addWidget(bokeh_lbl)
        layout.addStretch()
        return panel

    # ---- Status bar ---------------------------------------------------

    def _build_status_bar(self):
        bar = QtWidgets.QWidget()
        bar.setFixedHeight(28)
        bar.setStyleSheet(
            "background-color: " + C_BG_HEADER + ";"
            "border-top: 1px solid " + C_BORDER + ";"
        )
        layout = QtWidgets.QHBoxLayout(bar)
        layout.setContentsMargins(14, 0, 14, 0)
        layout.setSpacing(6)

        self._status_dot = QtWidgets.QLabel()
        self._status_dot.setFixedSize(8, 8)
        self._status_dot.setStyleSheet(
            "background-color: " + C_STATUS_OK + "; border-radius: 4px;")
        layout.addWidget(self._status_dot)

        self._status_lbl = _label("Ready.", color=C_TEXT_SEC, size=10)
        layout.addWidget(self._status_lbl)
        layout.addStretch()
        return bar

    # ------------------------------------------------------------------
    # Camera management
    # ------------------------------------------------------------------

    def _populate_cameras(self, keep_current=False):
        """
        Rebuild the camera dropdown.
        If keep_current=True, restore the previously selected camera
        by shape name so Refresh never jumps to a different camera.
        """
        # Remember which shape is currently active before clearing
        prev_shape = self._current_camera()[1] if keep_current else None

        self._cam_combo.blockSignals(True)
        self._cam_combo.clear()
        cameras = self._core.get_all_cameras() if self._core else []

        if cameras:
            restore_idx = 0
            for i, (transform, shape) in enumerate(cameras):
                self._cam_combo.addItem(
                    transform + " (" + shape + ")",
                    userData=(transform, shape))
                # Match by shape name so renames don't break it
                if prev_shape and shape == prev_shape:
                    restore_idx = i
            self._cam_combo.blockSignals(False)
            self._cam_combo.setCurrentIndex(restore_idx)
            self._on_camera_changed(restore_idx)
        else:
            self._cam_combo.addItem("-- No render cameras found --")
            self._cam_combo.blockSignals(False)
            self._set_status("No render cameras in scene.", "warn")

    def _current_camera(self):
        data = self._cam_combo.currentData()
        if isinstance(data, tuple):
            return data
        return (None, None)

    # ------------------------------------------------------------------
    # Callbacks
    # ------------------------------------------------------------------

    def _on_camera_changed(self, _index):
        transform, shape = self._current_camera()
        if not shape:
            return
        if self._core:
            self._core.switch_viewport_to_camera(transform)
            self._core.set_active_camera(transform, shape)
            self._load_camera_values(shape)
            # Install live sync -- fires when Arnold tab or Channel Box changes attrs
            self._core.install_sync_callback(self._on_maya_attr_changed)
        self._set_status("Camera: " + transform)

    def _on_add_camera(self):
        """
        Create a new Maya camera named RFX_Camera (auto-incremented
        by Maya if the name already exists), refresh the list and
        select the new camera automatically.
        """
        import maya.cmds as _cmds
        try:
            # Create with base name -- Maya appends _1, _2 etc. if needed
            result = _cmds.camera(
                name="RFX_Camera",
                focalLength=35,
                centerOfInterest=5
            )
            new_transform = result[0]
            new_shape     = result[1]
            # Refresh and auto-select the new camera
            self._populate_cameras(keep_current=False)
            for i in range(self._cam_combo.count()):
                data = self._cam_combo.itemData(i)
                if isinstance(data, tuple) and data[1] == new_shape:
                    self._cam_combo.setCurrentIndex(i)
                    break
            self._set_status("Created: " + new_transform)
        except Exception as exc:
            self._set_status("Create camera failed: " + str(exc), "err")

    def _on_remove_camera(self):
        """
        Delete the currently selected camera from the Maya scene.
        Shows a confirmation dialog first.
        """
        import maya.cmds as cmds
        transform, shape = self._current_camera()
        if not transform:
            self._set_status("No camera selected.", "warn")
            return

        # Confirmation dialog
        reply = QtWidgets.QMessageBox.question(
            self,
            "Delete Camera",
            "Delete camera '" + transform + "' from the scene?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.No
        )
        if reply != QtWidgets.QMessageBox.Yes:
            return

        try:
            # Kill scriptJobs before deleting the node
            if self._core:
                self._core._kill_sync_jobs()
            cmds.delete(transform)
            self._populate_cameras(keep_current=False)
            self._set_status("Deleted: " + transform)
        except Exception as exc:
            self._set_status("Delete failed: " + str(exc), "err")

    def _on_refresh(self):
        self._populate_cameras(keep_current=True)
        self._set_status("Camera list refreshed.")

    def _on_dof_changed(self, state):
        _, shape = self._current_camera()
        if not shape or not self._core:
            return
        # state is an int from Qt: 2=Checked, 0=Unchecked
        val = 1 if (state == QtCore.Qt.Checked or state == 2) else 0
        # Always try aiEnableDOF first (confirmed present by diagnostics)
        if not self._core.safe_set(shape, "aiEnableDOF", val, "RFX_FP_dof"):
            self._core.safe_set(shape, "depthOfField", val, "RFX_FP_dof")
        self._set_status("DOF " + ("enabled" if val else "disabled"))

    def _on_focus_changed(self, value):
        _, shape = self._current_camera()
        if not shape or not self._core:
            return
        if not self._core.safe_set(shape, "aiFocusDistance", value, "RFX_FP_focus"):
            self._core.safe_set(shape, "focusDistance", value, "RFX_FP_focus")
        self._set_status("Focus distance: {:.4f}".format(value))

    def _on_aperture_changed(self, value):
        _, shape = self._current_camera()
        if not shape or not self._core:
            return
        self._core.safe_set(shape, "aiApertureSize", value, "RFX_FP_aperture")
        self._set_status("Aperture: {:.4f}".format(value))

    def _on_pick_clicked(self):
        _, shape = self._current_camera()
        if not shape:
            self._set_status("Select a render camera first.", "warn")
            return
        self._set_status("Click surface or press Esc to cancel...", "ok")
        if self._core:
            self._core.start_pick(shape, self._on_pick_result)

    def _on_pick_result(self, distance):
        self._focus_spin.blockSignals(True)
        self._focus_spin.setValue(distance)
        self._focus_spin.blockSignals(False)
        self._set_status("Focus distance set to {:.4f}".format(distance))

    def _on_about(self):
        dlg = AboutDialog(parent=self)
        dlg.exec()

    def _load_camera_values(self, shape):
        if not shape or not self._core:
            return

        dof_attr = ("aiEnableDOF"
                    if self._core.attr_exists(shape, "aiEnableDOF")
                    else "depthOfField")
        dof_val = bool(self._core.safe_get(shape, dof_attr, 0.0))
        self._dof_check.blockSignals(True)
        self._dof_check.setChecked(dof_val)
        self._dof_check.blockSignals(False)

        fd_attr = ("aiFocusDistance"
                   if self._core.attr_exists(shape, "aiFocusDistance")
                   else "focusDistance")
        fd_val = self._core.safe_get(shape, fd_attr, 100.0)
        self._focus_spin.blockSignals(True)
        self._focus_spin.setValue(fd_val)
        self._focus_spin.blockSignals(False)

        ap_val = self._core.safe_get(shape, "aiApertureSize", 0.1)
        self._aperture_spin.blockSignals(True)
        self._aperture_spin.setValue(ap_val)
        self._aperture_spin.blockSignals(False)

    def _set_status(self, msg, level="ok"):
        self._status_lbl.setText(msg)
        colors = {"ok": C_STATUS_OK, "warn": C_STATUS_WARN, "err": C_STATUS_ERR}
        self._status_dot.setStyleSheet(
            "background-color: " + colors.get(level, C_STATUS_OK) + ";"
            "border-radius: 4px;"
        )

    def _on_maya_attr_changed(self, attr_name, value):
        """
        Called by core scriptJob when Maya changes a DOF attribute
        externally -- Arnold tab, Channel Box, undo, etc.
        Updates the relevant UI control without triggering a write-back.
        """
        if attr_name == "aiEnableDOF":
            self._dof_check.blockSignals(True)
            self._dof_check.setChecked(bool(value))
            self._dof_check.blockSignals(False)
            self._set_status("DOF " + ("enabled" if value else "disabled"))

        elif attr_name == "aiFocusDistance":
            self._focus_spin.blockSignals(True)
            self._focus_spin.setValue(float(value))
            self._focus_spin.blockSignals(False)
            self._set_status("Focus distance: {:.4f}".format(float(value)))

        elif attr_name == "aiApertureSize":
            self._aperture_spin.blockSignals(True)
            self._aperture_spin.setValue(float(value))
            self._aperture_spin.blockSignals(False)
            self._set_status("Aperture: {:.4f}".format(float(value)))

    def closeEvent(self, event):
        if self._core:
            self._core.cleanup_all()
        super(FocusPickerWindow, self).closeEvent(event)


# ===========================================================================
# Entry point
# ===========================================================================

_window_instance = None


def launch():
    global _window_instance
    if _window_instance is not None:
        try:
            if shiboken6.isValid(_window_instance):
                _window_instance.show()
                _window_instance.raise_()
                _window_instance.activateWindow()
                return
        except Exception:
            pass

    parent = _maya_main_window()
    _window_instance = FocusPickerWindow(parent=parent)
    _window_instance.show()
    _window_instance.raise_()
    _window_instance.activateWindow()
