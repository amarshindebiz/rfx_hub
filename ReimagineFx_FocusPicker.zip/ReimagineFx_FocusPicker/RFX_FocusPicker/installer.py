"""
RFX_FocusPicker - installer.py
================================
Maya shelf installer for the RFX FocusPicker plugin.

Usage - run from the Maya Script Editor (Python tab):

    import sys
    sys.path.insert(0, r"C:/Users/YourName/Documents/maya/2026/scripts")
    import RFX_FocusPicker.installer as installer
    installer.install()

To remove the shelf button:

    installer.uninstall()

Code rules:
  - No unicode dashes, smart quotes, or special characters.
  - All comments use only standard ASCII characters.
  - No f-strings. Plain string concatenation only.
  - Every function has a body.
  - 4-space indentation, never tabs.
  - No hardcoded absolute paths anywhere.
  - Runs first time in Maya 2025+ without errors.
  - Uses maya.cmds and maya.mel only, no external dependencies.
"""
from __future__ import annotations

import os
import sys

import maya.cmds as cmds
import maya.mel as mel

# ---------------------------------------------------------------------------
# Constants -- shared across all RFX plugins, never change these values
# ---------------------------------------------------------------------------
SHELF_NAME    = "ReimagineFx_Tools"
BUTTON_LABEL  = ""
BUTTON_ANNO   = "RFX_FocusPicker"
ICON_NAME     = "rfx_focuspicker_icon.png"
FALLBACK_ICON = "render.png"

# ---------------------------------------------------------------------------
# Plugin folder -- resolved relative to this file.
# __file__ is safe here because installer.py is always imported, never exec'd.
# ---------------------------------------------------------------------------
_PLUGIN_DIR = os.path.normpath(os.path.dirname(os.path.abspath(__file__)))
_ICON_PATH  = os.path.join(_PLUGIN_DIR, "icons", ICON_NAME)


# ===========================================================================
# Icon helper
# ===========================================================================

def _resolve_icon():
    """
    Return the icon path for the shelf button.
    Priority: custom PNG -> custom SVG -> built-in Maya fallback.
    Never crashes even if both custom files are missing.
    """
    if os.path.isfile(_ICON_PATH):
        return _ICON_PATH
    svg_path = os.path.join(_PLUGIN_DIR, "icons", "rfx_focuspicker_icon_dark.svg")
    if os.path.isfile(svg_path):
        return svg_path
    return FALLBACK_ICON


# ===========================================================================
# Button command
# ===========================================================================

def _build_button_command():
    """
    Build the Python command string executed by the shelf button.
    Path is calculated relative to installer.py -- no hardcoded paths.
    """
    # _PLUGIN_DIR is the RFX_FocusPicker package folder.
    # The parent of that folder must be on sys.path so the package is importable.
    scripts_dir = os.path.normpath(os.path.dirname(_PLUGIN_DIR))
    lines = [
        "import sys",
        "plugin_dir = " + repr(scripts_dir),
        "if plugin_dir not in sys.path:",
        "    sys.path.insert(0, plugin_dir)",
        "from RFX_FocusPicker import browser",
        "browser.launch()",
    ]
    return "\n".join(lines)


# ===========================================================================
# Shelf helpers
# ===========================================================================

def shelf_exists():
    """
    Return True if a shelf tab named SHELF_NAME already exists in Maya.
    Uses cmds only -- never calls addNewShelf MEL which may not be loaded.
    """
    top_level = mel.eval("$tmp = $gShelfTopLevel")
    labels = cmds.shelfTabLayout(top_level, query=True, tabLabel=True) or []
    return SHELF_NAME in labels


def _get_shelf_node():
    """
    Return the shelfLayout node name for SHELF_NAME, or None if not found.
    """
    top_level   = mel.eval("$tmp = $gShelfTopLevel")
    all_shelves = cmds.shelfTabLayout(top_level, query=True, childArray=True) or []
    labels      = cmds.shelfTabLayout(top_level, query=True, tabLabel=True)   or []
    for node, label in zip(all_shelves, labels):
        if label == SHELF_NAME:
            return node
    return None


def _create_shelf():
    """
    Create the ReimagineFx_Tools shelf tab using cmds.shelfLayout.
    This works regardless of Maya startup state -- no MEL proc required.
    Returns the new shelf layout node name.
    """
    top_level = mel.eval("$tmp = $gShelfTopLevel")
    # shelfLayout parented to the top-level tab creates a new shelf tab
    shelf_node = cmds.shelfLayout(SHELF_NAME, parent=top_level)
    return shelf_node


def _ensure_shelf_exists():
    """
    Return the shelf layout node for SHELF_NAME.
    Creates the shelf first if it does not exist.
    Never touches or modifies an existing shelf.
    """
    node = _get_shelf_node()
    if node:
        return node
    return _create_shelf()


def button_exists_on_shelf(shelf_node):
    """
    Return True if a button with annotation BUTTON_ANNO already exists
    on shelf_node. Used to prevent duplicate buttons on repeated installs.
    """
    children = cmds.shelfLayout(shelf_node, query=True, childArray=True) or []
    for child in children:
        try:
            if cmds.objectTypeUI(child) == "shelfButton":
                anno = cmds.shelfButton(child, query=True, annotation=True) or ""
                if anno == BUTTON_ANNO:
                    return True
        except Exception:
            pass
    return False


def _find_button_on_shelf(shelf_node):
    """
    Return the UI name of the shelf button with annotation BUTTON_ANNO,
    or None if not found.
    """
    children = cmds.shelfLayout(shelf_node, query=True, childArray=True) or []
    for child in children:
        try:
            if cmds.objectTypeUI(child) == "shelfButton":
                anno = cmds.shelfButton(child, query=True, annotation=True) or ""
                if anno == BUTTON_ANNO:
                    return child
        except Exception:
            pass
    return None


def _add_button(shelf_node):
    """
    Add the RFX_FocusPicker button to shelf_node.
    Only called after button_exists_on_shelf() confirms it is not there yet.
    """
    cmds.shelfButton(
        parent                = shelf_node,
        label                 = BUTTON_LABEL,
        annotation            = BUTTON_ANNO,
        image                 = _resolve_icon(),
        imageOverlayLabel     = "",
        overlayLabelColor     = (0.0, 0.0, 0.0),
        overlayLabelBackColor = (0.0, 0.0, 0.0, 0.0),
        command               = _build_button_command(),
        doubleClickCommand    = _build_button_command(),
        sourceType            = "python",
    )


def _save_shelves():
    """Save all shelves so changes survive a Maya restart."""
    try:
        # saveAllShelves MEL may not be loaded yet -- use savePrefs instead.
        # Maya writes shelf state as part of general prefs.
        cmds.savePrefs(general=True)
    except Exception:
        pass


# ===========================================================================
# Public API
# ===========================================================================

def install():
    """
    Install the RFX_FocusPicker shelf button.

    - Creates the ReimagineFx_Tools shelf if it does not exist.
    - Adds the button only if it is not already present.
    - Safe to run multiple times -- never creates duplicates.
    - Shows a confirmation dialog on success.
    """
    shelf_node = _ensure_shelf_exists()

    if not shelf_node:
        cmds.confirmDialog(
            title         = "RFX Installer",
            message       = "Could not create or find the shelf. Please try again after Maya has fully loaded.",
            button        = ["OK"],
            defaultButton = "OK",
        )
        return

    if button_exists_on_shelf(shelf_node):
        cmds.confirmDialog(
            title         = "RFX Installer",
            message       = (
                BUTTON_ANNO + " is already installed on the '"
                + SHELF_NAME + "' shelf.\n"
                "No changes were made."
            ),
            button        = ["OK"],
            defaultButton = "OK",
        )
        return

    _add_button(shelf_node)
    _save_shelves()

    cmds.confirmDialog(
        title         = "RFX Installer",
        message       = (
            BUTTON_ANNO + " has been added to the '"
            + SHELF_NAME + "' shelf.\n\n"
            "Click the button to launch the tool."
        ),
        button        = ["OK"],
        defaultButton = "OK",
    )


def uninstall():
    """
    Remove the RFX_FocusPicker shelf button.

    - Removes ONLY the button, never the shelf itself,
      so other RFX tools on the same shelf are not affected.
    - Shows a confirmation dialog when finished.
    """
    shelf_node = _get_shelf_node()

    if not shelf_node:
        cmds.confirmDialog(
            title         = "RFX Uninstaller",
            message       = (
                "Shelf '" + SHELF_NAME + "' was not found. "
                "Nothing to remove."
            ),
            button        = ["OK"],
            defaultButton = "OK",
        )
        return

    button = _find_button_on_shelf(shelf_node)

    if not button:
        cmds.confirmDialog(
            title         = "RFX Uninstaller",
            message       = (
                BUTTON_ANNO + " was not found on the '"
                + SHELF_NAME + "' shelf. Nothing to remove."
            ),
            button        = ["OK"],
            defaultButton = "OK",
        )
        return

    cmds.deleteUI(button, control=True)
    _save_shelves()

    cmds.confirmDialog(
        title         = "RFX Uninstaller",
        message       = (
            BUTTON_ANNO + " has been removed from the '"
            + SHELF_NAME + "' shelf."
        ),
        button        = ["OK"],
        defaultButton = "OK",
    )
