# RFX_GLTF_Exporter
# Maya glTF 2.0 / GLB exporter built for production lookdev and web delivery.
# PySide6, dockable, RFX dark amber theme.

from . import settings


def launch():
    # Public entry point. Opens the dockable exporter UI in Maya.
    from .ui import browser
    return browser.show()


def version():
    return settings.PLUGIN_VERSION
