# Top-level orchestration. Walks transforms, builds hierarchy in glTF nodes,
# extracts meshes/materials, copies/embeds textures, writes .gltf or .glb,
# returns a structured report.

import os
import traceback

from maya import cmds
import maya.utils

from .. import settings
from . import scene_scan
from . import mesh_extract
from . import material_utils
from . import texture_utils
from . import light_extract
from . import validators
from .gltf_writer import GltfWriter


def _read_matrix(transform, world=False):
    name = transform.split("|")[-1].split(":")[-1]
    attr = "worldMatrix[0]" if world else "matrix"
    try:
        value = cmds.getAttr("{0}.{1}".format(transform, attr))
        matrix = list(value)
    except Exception:
        matrix = [
            1.0, 0.0, 0.0, 0.0,
            0.0, 1.0, 0.0, 0.0,
            0.0, 0.0, 1.0, 0.0,
            0.0, 0.0, 0.0, 1.0,
        ]
    return {"name": name, "matrix": matrix}


class GLTFExporter(object):

    def __init__(self, options, progress_cb=None, log_cb=None):
        merged = dict(settings.DEFAULT_OPTIONS)
        if options:
            merged.update(options)
        self.options = merged
        self.warnings = []
        self.progress_cb = progress_cb
        self.log_cb = log_cb
        self._cancelled = False
        self._tex_index = {}
        self._tex_index_built = False
        self._tex_roots = []
        self._texture_cache = {}

    def cancel(self):
        self._cancelled = True

    def _log(self, msg):
        try:
            if self.log_cb:
                self.log_cb(msg)
        except Exception:
            pass

    def _progress(self, pct, msg=""):
        try:
            if self.progress_cb:
                self.progress_cb(int(pct), msg)
        except Exception:
            pass

    def _maya_call(self, func, *args, **kwargs):
        try:
            if maya.utils.isRunningInMainThread():
                return func(*args, **kwargs)
        except Exception:
            pass

        def _invoke():
            return func(*args, **kwargs)

        return maya.utils.executeInMainThreadWithResult(_invoke)

    # ---------- texture intake ----------

    def _texture_search_roots(self, out_dir):
        # Conservative folders to scan when a texture's stored path is stale.
        # Whole projects and parent folders can contain millions of files.
        roots = []
        try:
            scene = cmds.file(query=True, sceneName=True)
            if scene:
                sdir = os.path.dirname(scene)
                roots.append(sdir)
        except Exception:
            pass
        try:
            ws = cmds.workspace(query=True, rootDirectory=True)
            if ws:
                roots.append(os.path.join(ws, "sourceimages"))
        except Exception:
            pass
        if out_dir:
            roots.append(out_dir)
        roots.extend(self.options.get("texture_search_dirs", []) or [])
        seen = set()
        uniq = []
        for r in roots:
            try:
                if r and os.path.isdir(r):
                    key = os.path.normcase(os.path.abspath(r))
                    if key not in seen:
                        seen.add(key)
                        uniq.append(r)
            except Exception:
                pass
        return uniq

    def _resolve_texture_path(self, source_path):
        # Most authored paths are valid. Only pay for a recovery scan when a
        # literal path is missing, and build that index at most once per export.
        resolved, relocated = texture_utils.resolve_texture_path(
            source_path, self._tex_index)
        if source_path and not relocated and not os.path.isfile(
                os.path.normpath(source_path)) and not self._tex_index_built:
            self._tex_index = texture_utils.build_texture_index(self._tex_roots)
            self._tex_index_built = True
            resolved, relocated = texture_utils.resolve_texture_path(
                source_path, self._tex_index)
        return resolved, relocated

    def _prepare_texture(self, source_path, out_dir, embed):
        # Returns (texture_info_dict, warnings) or (None, warnings).
        if not source_path:
            return None, []
        warns = []
        # Recover textures whose stored path is stale (moved/renamed folders).
        resolved, relocated = self._resolve_texture_path(source_path)
        if relocated:
            warns.append("Recovered moved texture '{0}' -> '{1}'".format(
                source_path, resolved))
            source_path = resolved
        max_size = int(self.options.get("max_texture_size", 0) or 0)
        try:
            normalized_source = os.path.normcase(os.path.abspath(source_path))
        except Exception:
            normalized_source = source_path
        cache_key = (
            normalized_source,
            os.path.normcase(os.path.abspath(out_dir)),
            bool(embed),
            bool(self.options.get("copy_textures", True)),
            max_size,
        )
        cached = self._texture_cache.get(cache_key)
        if cached is not None:
            return dict(cached), warns
        native_path, native_warn = texture_utils.ensure_native_texture(
            source_path, out_dir, max_size=max_size
        )
        native_warn = warns + native_warn
        if native_path is None:
            return None, native_warn
        source_path = native_path
        if embed:
            data = texture_utils.read_texture_bytes(source_path)
            if data is None:
                return None, native_warn + [
                    "Missing or unreadable texture: '{0}'".format(source_path)
                ]
            mime_type = texture_utils.mime_for_path(source_path)
            if not mime_type:
                return None, native_warn + [
                    "Unsupported glTF image format: '{0}'".format(source_path)
                ]
            info = {
                "embed_bytes": data,
                "mime_type": mime_type,
                "source_path": source_path,
            }
            self._texture_cache[cache_key] = dict(info)
            return info, native_warn
        if self.options.get("copy_textures", True):
            dest, warn = texture_utils.copy_texture(source_path, out_dir)
            if dest is None:
                return None, native_warn + warn
            info = {
                "uri": texture_utils.normalize_uri(dest, out_dir)
            }
            self._texture_cache[cache_key] = dict(info)
            return info, native_warn + warn
        info = {
            "uri": texture_utils.normalize_uri(source_path, out_dir)
        }
        self._texture_cache[cache_key] = dict(info)
        return info, native_warn

    def _prepare_material(self, material_node, out_dir, embed):
        mat = material_utils.extract_material(material_node)
        # Resolve every texture path up front so the packers (which read files
        # directly) also benefit from stale-path recovery.
        source_textures = {}
        for slot, pth in (mat.get("textures") or {}).items():
            if pth:
                rp, relocated = self._resolve_texture_path(pth)
                if relocated:
                    self.warnings.append(
                        "Recovered moved texture '{0}' -> '{1}'".format(pth, rp))
                source_textures[slot] = rp
            else:
                source_textures[slot] = pth
        tex_section = {}
        max_size = int(self.options.get("max_texture_size", 0) or 0)
        opacity_path = source_textures.pop("opacity", None)
        base_color_path = source_textures.get("base_color")
        if opacity_path:
            packed_color, alpha_warn = texture_utils.pack_base_color_alpha(
                base_color_path, opacity_path, out_dir, max_size=max_size
            )
            if alpha_warn:
                self.warnings.extend(alpha_warn)
            if packed_color:
                source_textures["base_color"] = packed_color

        metallic_path = source_textures.pop("metallic", None)
        roughness_path = source_textures.pop("roughness", None)
        packed_path, packed_warn = texture_utils.pack_metallic_roughness(
            metallic_path, roughness_path, out_dir,
            invert_roughness=bool(mat.get("roughness_invert")),
            max_size=max_size,
        )
        if packed_warn:
            self.warnings.extend(packed_warn)
        if packed_path:
            source_textures["metallic_roughness"] = packed_path

        for slot, src_path in source_textures.items():
            if not src_path:
                continue
            info, warns = self._prepare_texture(src_path, out_dir, embed)
            if warns:
                self.warnings.extend(warns)
            if info:
                tex_section[slot] = info
        mat["textures"] = tex_section
        return mat

    # ---------- hierarchy ----------

    def _build_hierarchy(self, writer, transforms):
        # Maps Maya DAG path -> glTF node index.
        # Creates intermediate parent transform nodes as needed when
        # include_hierarchy is True; otherwise meshes are flat roots.
        if not self.options.get("include_hierarchy", True):
            mesh_holders = {}
            for tpath in transforms:
                transform_data = _read_matrix(tpath, world=True)
                idx = writer.add_node(
                    transform_data["name"],
                    matrix=transform_data["matrix"],
                )
                mesh_holders[tpath] = idx
            return mesh_holders

        path_to_node = {}
        mesh_holders = {}
        # Build parents first via ancestry walks.
        for tpath in transforms:
            ancestors = scene_scan.get_all_ancestors(tpath) + [tpath]
            parent_node_idx = None
            for anc in ancestors:
                if anc in path_to_node:
                    parent_node_idx = path_to_node[anc]
                    continue
                transform_data = _read_matrix(anc, world=False)
                idx = writer.add_node(
                    transform_data["name"],
                    parent_index=parent_node_idx,
                    matrix=transform_data["matrix"],
                )
                path_to_node[anc] = idx
                parent_node_idx = idx
            mesh_holders[tpath] = path_to_node[tpath]
        return mesh_holders

    # ---------- main ----------

    def export(self):
        report = {
            "success": False,
            "output_path": self.options.get("output_path"),
            "format": self.options.get("format"),
            "mesh_count": 0,
            "primitive_count": 0,
            "triangle_count": 0,
            "material_count": 0,
            "texture_count": 0,
            "warnings": self.warnings,
            "error": None,
        }

        try:
            ok, msg = validators.validate_options(self.options)
            if not ok:
                report["error"] = msg
                return report

            mode = self.options["export_mode"]
            if mode == "selected":
                transforms = self._maya_call(
                    scene_scan.get_selected_mesh_transforms
                )
            else:
                transforms = self._maya_call(
                    scene_scan.get_visible_mesh_transforms
                )
            if not transforms:
                report["error"] = ("No polygon meshes selected." if mode == "selected"
                                   else "No visible polygon meshes found.")
                return report

            out_path = self.options["output_path"]
            out_dir = os.path.dirname(out_path) or "."
            fmt = self.options.get("format", "gltf")
            embed = bool(self.options.get("embed_textures", False)) and fmt == "glb"

            writer = GltfWriter()
            writer.set_embed_textures(embed)

            # Recovery roots are indexed lazily only if a stored path is stale.
            self._progress(1, "Preparing textures")
            try:
                self._tex_roots = self._maya_call(
                    self._texture_search_roots, out_dir)
                self._tex_index = {}
                self._tex_index_built = False
            except Exception:
                self._tex_roots = []
                self._tex_index = {}
                self._tex_index_built = True

            self._progress(2, "Building hierarchy")
            mesh_holders = self._maya_call(
                self._build_hierarchy, writer, transforms
            )

            unique_materials = set()
            unique_textures = set()
            total_triangles = 0
            total_primitives = 0

            for i, tpath in enumerate(transforms):
                if self._cancelled:
                    report["error"] = "Cancelled by user."
                    return report
                self._progress(5 + int(85 * i / max(len(transforms), 1)),
                               "Extracting {0}".format(tpath.split('|')[-1]))
                try:
                    mesh_data, mwarn = self._maya_call(
                        mesh_extract.extract_mesh, tpath, self.options
                    )
                    self.warnings.extend(mwarn)
                    if not mesh_data or not mesh_data.get("primitives"):
                        self.warnings.append("Skipped '{0}': no primitives.".format(tpath))
                        continue

                    primitives_payload = []
                    for prim in mesh_data["primitives"]:
                        mat = self._maya_call(
                            self._prepare_material,
                            prim.get("material_node"),
                            out_dir,
                            embed,
                        )
                        unique_materials.add(mat.get("name"))
                        for slot, info in (mat.get("textures") or {}).items():
                            key = info.get("uri") or info.get("source_path")
                            if key:
                                unique_textures.add(key)
                        prim_payload = dict(prim)
                        prim_payload["material"] = mat
                        primitives_payload.append(prim_payload)
                        total_primitives += 1
                        total_triangles += prim.get("triangle_count", 0)

                    mesh_index = writer.add_mesh(mesh_data["name"], primitives_payload)
                    holder_idx = mesh_holders.get(tpath)
                    if holder_idx is not None:
                        writer._nodes[holder_idx]["mesh"] = mesh_index
                    report["mesh_count"] += 1
                except Exception as exc:
                    self.warnings.append(
                        "Failed to export '{0}': {1}".format(tpath, exc)
                    )
                    self.warnings.append(traceback.format_exc())

            if report["mesh_count"] == 0:
                report["error"] = "Nothing was exported."
                return report

            # Lights (KHR_lights_punctual). Area lights are approximated as
            # point lights; the HDRI skydome cannot be carried by glTF.
            report["light_count"] = 0
            if self.options.get("include_lights", True):
                self._progress(90, "Collecting lights")
                try:
                    lights = self._maya_call(light_extract.extract_lights, self.options)
                    for entry in lights:
                        li = writer.add_light(entry["light"])
                        writer.add_node(entry["name"], matrix=entry["matrix"], light_index=li)
                    report["light_count"] = len(lights)
                    sky, hdri = self._maya_call(light_extract.find_hdri, self.options)
                    if sky:
                        self.warnings.append(
                            "HDRI environment '{0}' was NOT exported -- glTF has no "
                            "world/IBL that Blender imports. Load it manually in "
                            "Blender's World shader.".format(hdri or sky))
                except Exception as exc:
                    self.warnings.append("Light export failed: {0}".format(exc))

            self._progress(92, "Writing glTF buffers")
            if fmt == "glb":
                info = writer.write_glb(out_path)
            else:
                info = writer.write_gltf(out_path)

            report["triangle_count"] = total_triangles
            report["primitive_count"] = total_primitives
            report["material_count"] = len(unique_materials)
            report["texture_count"] = len(unique_textures)
            report["bin_path"] = info.get("bin_path")
            report["success"] = True

            if self.options.get("open_folder"):
                try:
                    import webbrowser
                    webbrowser.open(out_dir)
                except Exception:
                    pass

            self._progress(100, "Done")
            return report

        except Exception as exc:
            report["error"] = "Unhandled exporter error: {0}".format(exc)
            self.warnings.append(traceback.format_exc())
            return report
