# Lightweight validation: output path, options, extracted mesh data.

import os


def validate_output_path(path, fmt):
    if not path:
        return False, "Output path is empty."
    path = str(path).strip()
    if not path:
        return False, "Output path is empty."
    expected = ".glb" if fmt == "glb" else ".gltf"
    if not path.lower().endswith(expected):
        return False, "Output path must end with {0}".format(expected)
    folder = os.path.dirname(path)
    if folder and not os.path.isdir(folder):
        try:
            os.makedirs(folder)
        except Exception as exc:
            return False, "Cannot create output folder '{0}': {1}".format(folder, exc)
    return True, ""


def validate_options(options):
    if not isinstance(options, dict):
        return False, "Options must be a dict."
    mode = options.get("export_mode", "selected")
    if mode not in ("selected", "visible"):
        return False, "Unknown export mode: {0}".format(mode)
    fmt = options.get("format", "gltf")
    if fmt not in ("gltf", "glb"):
        return False, "Unknown format: {0}".format(fmt)
    return validate_output_path(options.get("output_path", ""), fmt)


def validate_primitive(prim):
    warnings = []
    name = prim.get("name", "<unnamed>")
    if not prim.get("positions"):
        warnings.append("Primitive '{0}' has no positions.".format(name))
    if not prim.get("indices"):
        warnings.append("Primitive '{0}' has no triangles.".format(name))
    pos = prim.get("positions") or []
    vcount = len(pos) // 3 if pos else 0
    for key, stride in (("normals", 3), ("uvs", 2), ("colors", 4), ("tangents", 4)):
        arr = prim.get(key) or []
        if arr and len(arr) // stride != vcount:
            warnings.append("Primitive '{0}' {1} count mismatch.".format(name, key))
    return warnings
