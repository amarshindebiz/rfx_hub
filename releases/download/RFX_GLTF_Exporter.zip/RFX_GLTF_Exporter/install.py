# RFX_GLTF_Exporter installer entry point.
# Run in Maya's Script Editor (Python tab):
#
#   import sys
#   sys.path.insert(0, r"C:/Users/<you>/Documents/maya/2026/scripts")
#   from RFX_GLTF_Exporter import install
#   install.install()

import os
import sys

from maya import cmds


def _scripts_root():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(here)


def _ensure_sys_path():
    root = _scripts_root()
    if root not in sys.path:
        sys.path.insert(0, root)


def install():
    _ensure_sys_path()
    try:
        from RFX_GLTF_Exporter.ui import installer as ui_installer
    except Exception as exc:
        cmds.warning("RFX_GLTF_Exporter: could not import installer: {0}".format(exc))
        return False
    ok_menu = False
    ok_shelf = False
    try:
        ok_menu = ui_installer.install_menu()
    except Exception as exc:
        cmds.warning("RFX_GLTF_Exporter: menu install failed: {0}".format(exc))
    try:
        ok_shelf = ui_installer.install_shelf_button()
    except Exception as exc:
        cmds.warning("RFX_GLTF_Exporter: shelf install failed: {0}".format(exc))
    if ok_menu or ok_shelf:
        print("[RFX_GLTF_Exporter] Installed. Menu: Reimagine Fx Tools  Shelf: RFXglTF")
        return True
    return False


if __name__ == "__main__":
    install()
