# RFX glTF Exporter -- Modern Studio Dark theme for PySide6 in Maya 2026.
# Cyan accent on near-black, rounded panel + cards, segmented controls.
# No f-strings. No unicode. ASCII only.

import os

from .. import settings


def _check_icon_url():
    # Forward-slash absolute path to the checkmark icon, for QSS url().
    path = os.path.join(settings.plugin_dir(), "icons", "check.png")
    return path.replace("\\", "/")


COLORS = {
    "bg":        "#09090b",
    "panel":     "#18181b",
    "card":      "#1f1f22",
    "card_hi":   "#27272a",
    "line":      "#26262a",
    "line_str":  "#2f2f34",
    "field":     "#0a0a0b",
    "text":      "#f4f4f5",
    "text_dim":  "#a1a1aa",
    "text_mute": "#71717a",
    "accent":    "#22d3ee",
    "accent_hi": "#67e8f9",
    "accent_bg": "#0f2a30",
    "good":      "#4fcb83",
}


def color(key):
    return COLORS.get(key, "#000000")


def stylesheet():
    s = COLORS
    parts = [
        "QWidget { background: " + s["bg"] + "; color: " + s["text"]
        + "; font-family: 'Inter','Segoe UI',Arial; font-size: 12px; }",
        "QLabel { background: transparent; }",

        "QFrame#RFXPanel { background: " + s["panel"] + "; border: none; border-radius: 0; }",
        "QFrame#RFXHeader, QFrame#RFXFooter { background: transparent; }",
        "QFrame#RFXSep { background: " + s["line"]
        + "; max-height: 1px; min-height: 1px; border: none; }",

        "QLabel#RFXBrand { font-size: 13px; font-weight: 600; letter-spacing: 1px; color: "
        + s["text"] + "; }",
        "QLabel#RFXBrandSub { font-size: 9px; font-weight: 600; letter-spacing: 2px; color: "
        + s["accent"] + "; }",
        "QLabel#RFXBadge { color: " + s["text_mute"]
        + "; background: rgba(255,255,255,0.05); padding: 2px 6px; border-radius: 4px; font-size: 10px; }",
        "QPushButton#RFXAbout { background: transparent; color: " + s["text_mute"]
        + "; border: 1px solid " + s["line_str"]
        + "; border-radius: 5px; padding: 3px 9px; font-size: 10px; }",
        "QPushButton#RFXAbout:hover { color: " + s["accent"] + "; border-color: " + s["accent"] + "; }",
        "QLabel#RFXEyebrow { color: " + s["text_mute"]
        + "; font-size: 10px; font-weight: 600; letter-spacing: 1px; }",
        "QLabel#RFXMeta { color: " + s["text_mute"] + "; font-size: 10px; }",
        "QLabel#RFXPill { color: " + s["accent"] + "; background: " + s["accent_bg"]
        + "; padding: 2px 7px; border-radius: 4px; font-size: 10px; font-weight: 600; }",

        "QFrame#RFXCard { background: " + s["card"] + "; border: 1px solid "
        + s["line"] + "; border-radius: 12px; }",

        "QLineEdit, QComboBox { background: " + s["field"] + "; border: 1px solid "
        + s["line"] + "; border-radius: 8px; padding: 7px 10px; color: " + s["text_dim"]
        + "; font-family: 'JetBrains Mono','Consolas',monospace; font-size: 11px; }",
        "QLineEdit:focus, QComboBox:focus { border-color: " + s["accent"] + "; color: "
        + s["text"] + "; }",
        "QComboBox::drop-down { border: none; width: 18px; }",
        "QComboBox QAbstractItemView { background: " + s["field"] + "; color: " + s["text"]
        + "; border: 1px solid " + s["line_str"] + "; selection-background-color: "
        + s["accent_bg"] + "; selection-color: " + s["accent"] + "; outline: none; }",

        "QFrame#RFXSegGroup { background: " + s["field"] + "; border: 1px solid "
        + s["line"] + "; border-radius: 8px; }",
        "QPushButton#RFXSeg { background: transparent; color: " + s["text_dim"]
        + "; border: 1px solid transparent; border-radius: 6px; padding: 6px 10px; font-size: 12px; }",
        "QPushButton#RFXSeg:hover { color: " + s["text"] + "; }",
        "QPushButton#RFXSeg:checked { background: " + s["card_hi"] + "; color: " + s["text"]
        + "; border: 1px solid " + s["line_str"] + "; }",

        "QPushButton#RFXGhost { background: " + s["card_hi"] + "; color: " + s["text_dim"]
        + "; border: 1px solid " + s["line_str"] + "; border-radius: 8px; padding: 7px 14px; font-size: 12px; }",
        "QPushButton#RFXGhost:hover { background: #3f3f46; color: " + s["text"] + "; }",

        "QCheckBox { color: " + s["text_dim"] + "; font-size: 12px; spacing: 10px; background: transparent; }",
        "QCheckBox:hover { color: " + s["text"] + "; }",
        "QCheckBox::indicator { width: 18px; height: 18px; border-radius: 5px; background: "
        + s["field"] + "; border: 1px solid #3f3f46; }",
        "QCheckBox::indicator:unchecked:hover { border: 1px solid " + s["text_mute"] + "; }",
        "QCheckBox::indicator:checked { background: " + s["accent"] + "; border: 1px solid "
        + s["accent"] + "; image: url(\"" + _check_icon_url() + "\"); }",

        "QPlainTextEdit { background: " + s["field"] + "; border: 1px solid " + s["line"]
        + "; border-radius: 8px; color: " + s["text_dim"]
        + "; font-family: 'JetBrains Mono','Consolas',monospace; font-size: 10px; padding: 8px; }",

        "QProgressBar { background: " + s["card_hi"]
        + "; border: none; border-radius: 2px; max-height: 4px; min-height: 4px; text-align: center; color: transparent; }",
        "QProgressBar::chunk { background: " + s["accent"] + "; border-radius: 2px; }",

        "QPushButton#RFXExport { background: " + s["accent"]
        + "; color: #09090b; border: none; border-radius: 8px; padding: 11px 14px; font-size: 13px; font-weight: 600; }",
        "QPushButton#RFXExport:hover { background: " + s["accent_hi"] + "; }",
        "QPushButton#RFXExport:disabled { background: #3f3f46; color: " + s["text_mute"] + "; }",
        "QPushButton#RFXCancel { background: transparent; color: " + s["text_dim"]
        + "; border: 1px solid " + s["line_str"] + "; border-radius: 8px; padding: 11px 14px; font-size: 12px; }",
        "QPushButton#RFXCancel:hover { color: " + s["text"] + "; border-color: " + s["text_dim"] + "; }",
        "QPushButton#RFXCancel:disabled { color: #3f3f46; border-color: " + s["line"] + "; }",
        "QPushButton#RFXDone { background: " + s["good"]
        + "; color: #09090b; border: 1px solid " + s["good"]
        + "; border-radius: 8px; padding: 11px 14px; font-size: 12px; font-weight: 700; }",
        "QPushButton#RFXDone:hover { background: #6ee7a0; border-color: #6ee7a0; }",

        "QScrollArea { background: transparent; border: none; }",
        "QScrollBar:vertical { background: transparent; width: 8px; margin: 0; }",
        "QScrollBar::handle:vertical { background: " + s["line_str"] + "; border-radius: 4px; min-height: 24px; }",
        "QScrollBar::handle:vertical:hover { background: " + s["accent"] + "; }",
        "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }",
        "QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }",
    ]
    return "\n".join(parts)
