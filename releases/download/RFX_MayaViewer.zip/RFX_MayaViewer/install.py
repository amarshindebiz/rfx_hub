# RFX_MayaViewer - install.py
# Reimagine Fx
# Author: Amar Shinde
# Website: www.reimaginefx.com
#
# Run this once in Maya's Script Editor (Python tab) to install the shelf button.
#
# HOW TO USE:
#   1. Copy the RFX_MayaViewer folder into your Maya scripts directory, e.g.:
#        C:\Users\<you>\Documents\maya\2026\scripts\RFX_MayaViewer\
#
#   2. Open Maya's Script Editor (Python tab) and run:
#
#        import sys
#        sys.path.insert(0, r"C:\Users\<you>\Documents\maya\2026\scripts")
#        sys.path.insert(0, r"C:\Users\<you>\Documents\maya\2026\scripts\RFX_MayaViewer")
#        from RFX_MayaViewer.ui import installer
#        installer.install()
#
# A single "MayaViewer" button will appear on the ReimagineFx_Tools shelf.
# Click it to open the control panel where you can Start / Stop the server
# and see the IP address to enter in the iOS app.
#
# UNINSTALL:
#   Run the following to remove the shelf button:
#        from RFX_MayaViewer.ui import installer
#        installer.uninstall()

print("")
print("=" * 60)
print("  RFX Maya Viewer - Installer")
print("  Reimagine Fx")
print("=" * 60)
print("")
print("To install, run the following in Maya's Script Editor")
print("(Python tab):")
print("")
print("  import sys")
print("  sys.path.insert(0, r'C:\\Users\\<you>\\Documents\\maya\\2026\\scripts')")
print("  sys.path.insert(0, r'C:\\Users\\<you>\\Documents\\maya\\2026\\scripts\\RFX_MayaViewer')")
print("  from RFX_MayaViewer.ui import installer")
print("  installer.install()")
print("")
print("=" * 60)
