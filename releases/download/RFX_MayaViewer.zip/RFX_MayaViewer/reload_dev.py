# RFX_MayaViewer - reload_dev.py
# Reimagine Fx
#
# Paste this entire block into Maya's Script Editor (Python tab) to reload
# the plugin from disk. Safe to run multiple times during development.
#
# WHAT IT DOES:
#   1. Closes the open control panel window (if any)
#   2. Stops the WebSocket server (if running)
#   3. Purges all related modules from sys.modules
#   4. Deletes .pyc bytecode so Python reads fresh source
#   5. Re-imports and re-launches the control panel

import sys
import os
import shutil

# ---------------------------------------------------------------------------
# 1. Close the window
# ---------------------------------------------------------------------------
_win_mod = sys.modules.get("RFX_MayaViewer.ui.window")
if _win_mod is not None:
    try:
        if getattr(_win_mod, "_window_instance", None) is not None:
            _win_mod._window_instance.close()
            _win_mod._window_instance = None
            print("RFX_MayaViewer | Window closed.")
    except Exception as _e:
        print("RFX_MayaViewer | Could not close window: " + str(_e))

# ---------------------------------------------------------------------------
# 2. Stop the server
# ---------------------------------------------------------------------------
_mv_mod = sys.modules.get("rfx_mayaviewer")
if _mv_mod is not None:
    try:
        _mv_mod.stop_server()
        print("RFX_MayaViewer | Server stopped.")
    except Exception as _e:
        print("RFX_MayaViewer | Could not stop server: " + str(_e))

# ---------------------------------------------------------------------------
# 3. Purge all related modules from sys.modules
# ---------------------------------------------------------------------------
_prefixes = (
    "rfx_mayaviewer",
    "RFX_MayaViewer",
)
_to_remove = [k for k in list(sys.modules.keys()) if any(k == p or k.startswith(p + ".") for p in _prefixes)]
for _k in _to_remove:
    del sys.modules[_k]
    print("RFX_MayaViewer | Removed from sys.modules: " + _k)

# ---------------------------------------------------------------------------
# 4. Delete .pyc / __pycache__ bytecode files so Python reads fresh source
# ---------------------------------------------------------------------------
# Derive paths from this file's own location — works on any machine
_pkg_dir     = os.path.dirname(os.path.abspath(__file__))
_scripts_dir = os.path.dirname(_pkg_dir)

_pyc_dirs = [
    os.path.join(_pkg_dir, "__pycache__"),
    os.path.join(_pkg_dir, "ui", "__pycache__"),
]
for _d in _pyc_dirs:
    if os.path.isdir(_d):
        shutil.rmtree(_d)
        print("RFX_MayaViewer | Deleted: " + _d)

# ---------------------------------------------------------------------------
# 5. Ensure sys.path has both required entries
# ---------------------------------------------------------------------------
if _scripts_dir not in sys.path:
    sys.path.insert(0, _scripts_dir)
if _pkg_dir not in sys.path:
    sys.path.insert(0, _pkg_dir)

# ---------------------------------------------------------------------------
# 6. Re-launch
# ---------------------------------------------------------------------------
from RFX_MayaViewer.ui import window
window.launch()
print("RFX_MayaViewer | Reloaded and launched.")
