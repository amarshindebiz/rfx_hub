# RFX_MayaViewer - ui/installer.py
# Reimagine Fx
# Author: Amar Shinde
# Website: www.reimaginefx.com
#
# Adds a single "Maya Viewer" shelf button to ReimagineFx_Tools.
# Safe to run multiple times - will not create duplicates.

import os
import maya.cmds as cmds
import maya.mel as mel


SHELF_NAME        = "ReimagineFx_Tools"
BUTTON_LABEL      = "MayaViewer"
BUTTON_ANNOTATION = "RFX MayaViewer - Stream Maya scene to the iOS viewer app"
ICON_FILENAME     = "rfx_mayaviewer_start.png"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def install():
    """Add the Maya Viewer button to the shelf. Safe to re-run."""
    _ensure_shelf()

    if button_exists_on_shelf():
        cmds.confirmDialog(
            title="RFX Maya Viewer",
            message="RFX Maya Viewer is already installed on the " + SHELF_NAME + " shelf.",
            button=["OK"],
            defaultButton="OK",
        )
        return

    _add_button()

    cmds.confirmDialog(
        title="RFX Maya Viewer - Installed",
        message=(
            "RFX Maya Viewer has been added to the '" + SHELF_NAME + "' shelf.\n\n"
            "Click the shelf button to open the control panel."
        ),
        button=["OK"],
        defaultButton="OK",
    )


def uninstall():
    """Remove the Maya Viewer button. Never deletes the shelf itself."""
    if not shelf_exists():
        print("RFX_MayaViewer | Shelf '" + SHELF_NAME + "' not found. Nothing to uninstall.")
        return

    btn = _find_button()
    if btn:
        cmds.deleteUI(btn, control=True)
        print("RFX_MayaViewer | Shelf button removed.")
        cmds.confirmDialog(
            title="RFX Maya Viewer - Uninstalled",
            message="RFX Maya Viewer shelf button has been removed.",
            button=["OK"],
            defaultButton="OK",
        )
    else:
        print("RFX_MayaViewer | Button not found on shelf. Nothing to uninstall.")


def shelf_exists():
    try:
        shelf_layout = mel.eval("$tmp = $gShelfTopLevel")
        shelves = cmds.tabLayout(shelf_layout, q=True, childArray=True) or []
        return SHELF_NAME in shelves
    except Exception as err:
        print("RFX_MayaViewer | shelf_exists() error: " + str(err))
        return False


def button_exists_on_shelf():
    return _find_button() is not None


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _ensure_shelf():
    if shelf_exists():
        return
    try:
        shelf_layout = mel.eval("$tmp = $gShelfTopLevel")
        cmds.setParent(shelf_layout)
        mel.eval('addNewShelfTab "' + SHELF_NAME + '"')
        print("RFX_MayaViewer | Created shelf: " + SHELF_NAME)
    except Exception as err:
        print("RFX_MayaViewer | _ensure_shelf() error: " + str(err))


def _get_icon_path():
    this_file = os.path.abspath(__file__)
    ui_dir    = os.path.dirname(this_file)
    pkg_dir   = os.path.dirname(ui_dir)
    icon_path = os.path.join(pkg_dir, "icons", ICON_FILENAME)
    if os.path.isfile(icon_path):
        return icon_path
    print("RFX_MayaViewer | Icon not found at: " + icon_path + " - using fallback.")
    return "commandButton.png"


def _get_scripts_dir():
    this_file   = os.path.abspath(__file__)
    ui_dir      = os.path.dirname(this_file)
    pkg_dir     = os.path.dirname(ui_dir)
    scripts_dir = os.path.dirname(pkg_dir)
    return scripts_dir.replace("\\", "/")


def _get_launch_command():
    scripts_dir = _get_scripts_dir()
    pkg_dir     = scripts_dir.replace("\\", "/") + "/RFX_MayaViewer"
    return (
        "import sys\n"
        "if r'" + scripts_dir + "' not in sys.path:\n"
        "    sys.path.insert(0, r'" + scripts_dir + "')\n"
        "if r'" + pkg_dir + "' not in sys.path:\n"
        "    sys.path.insert(0, r'" + pkg_dir + "')\n"
        "from RFX_MayaViewer.ui import window\n"
        "window.launch()\n"
    )


def _find_button():
    if not shelf_exists():
        return None
    try:
        buttons = cmds.shelfLayout(SHELF_NAME, q=True, childArray=True) or []
        for btn in buttons:
            try:
                ann = cmds.shelfButton(btn, q=True, annotation=True) or ""
                if BUTTON_ANNOTATION in ann:
                    return btn
            except Exception:
                continue
    except Exception as err:
        print("RFX_MayaViewer | _find_button() error: " + str(err))
    return None


def _add_button():
    try:
        cmds.setParent(SHELF_NAME)
        cmds.shelfButton(
            label=BUTTON_LABEL,
            annotation=BUTTON_ANNOTATION,
            image1=_get_icon_path(),
            command=_get_launch_command(),
            sourceType="python",
            imageOverlayLabel="",
            overlayLabelColor=[1, 1, 1],
            overlayLabelBackColor=[0.0, 0.0, 0.0, 0.0],
        )
        print("RFX_MayaViewer | Shelf button added to: " + SHELF_NAME)
    except Exception as err:
        print("RFX_MayaViewer | _add_button() error: " + str(err))
