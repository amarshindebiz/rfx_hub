# RFX_MayaViewer - ui/window.py
# Reimagine Fx
# Author: Amar Shinde
# Website: www.reimaginefx.com

import os

import maya.OpenMayaUI as omui
from PySide6 import QtWidgets, QtCore, QtGui
from PySide6.QtCore import Qt
import shiboken6


PLUGIN_NAME    = "RFX Maya Viewer"
STUDIO_NAME    = "Reimagine Fx"
AUTHOR_NAME    = "Amar Shinde"
WEBSITE        = "https://www.reimaginefx.com"
VERSION        = "1.0"
BUILD          = "4"
WINDOW_TITLE   = "RFX Maya Viewer"
WINDOW_W       = 320

ICON_FILENAME  = "rfx_mayaviewer_start.png"

DESCRIPTION_1 = (
    "Maya Viewer was built by Amar Shinde at Reimagine Fx to help 3D artists "
    "inspect, present, and review Maya scenes directly from iPhone. It connects "
    "to a live Maya session, streams scene geometry, cameras, lights, materials, "
    "textures, stats, and transform controls, then brings that work into a clean "
    "mobile viewer and AR experience."
)
DESCRIPTION_2 = (
    "Every detail is designed to feel natural beside a Maya and Arnold workflow: "
    "fast scene previews, camera framing, wireframe and texture checks, "
    "selected-object viewing, snapshots, AR placement, and lightweight transform "
    "controls without pulling artists away from the desktop scene."
)

# -- Colour palette (matches the RFX suite) ----------------------------------
C_BG_BASE    = "#111213"
C_BG_INPUT   = "#1a1b1d"
C_BG_RAISED  = "#202124"
C_BG_DEEP    = "#0d0e0f"
C_BORDER     = "#2a2b2e"
C_BORDER_HI  = "#3a3b3e"
C_TEAL       = "#22c792"
C_TEAL_DIM   = "#0d6b50"
C_TEAL_MID   = "#0d8b50"
C_TEAL_DEEP  = "#0a3d2e"
C_TEAL_DARK  = "#084d38"
C_TEXT_PRI   = "#e8e9eb"
C_TEXT_SEC   = "#b0b2b8"
C_TEXT_DIM   = "#808288"
C_TEXT_MUTE  = "#4a4b50"
C_RED        = "#e05555"
C_RED_DIM    = "#5a1a1a"
C_RED_MID    = "#6a1a1a"
C_RED_DARK   = "#3a1010"


STYLESHEET = (
    "QWidget {"
    "    background-color: " + C_BG_BASE + ";"
    "    color: " + C_TEXT_SEC + ";"
    "    font-family: 'Segoe UI', 'SF Pro Text', 'Helvetica Neue', sans-serif;"
    "    font-size: 12px;"
    "}"
    "QLineEdit {"
    "    background-color: " + C_BG_INPUT + ";"
    "    border: 1px solid " + C_BORDER + ";"
    "    border-radius: 6px;"
    "    padding: 5px 8px;"
    "    color: " + C_TEXT_SEC + ";"
    "    font-size: 12px;"
    "    selection-background-color: " + C_TEAL_DIM + ";"
    "}"
    "QSpinBox {"
    "    background-color: " + C_BG_INPUT + ";"
    "    border: 1px solid " + C_BORDER + ";"
    "    border-radius: 6px;"
    "    padding: 4px 8px;"
    "    color: " + C_TEXT_SEC + ";"
    "    font-size: 12px;"
    "}"
    "QSpinBox::up-button, QSpinBox::down-button { width: 16px; border: none; background: transparent; }"
    "QToolTip {"
    "    background-color: " + C_BG_RAISED + ";"
    "    border: 1px solid " + C_BORDER_HI + ";"
    "    color: " + C_TEXT_SEC + ";"
    "    font-size: 11px;"
    "    padding: 4px 8px;"
    "}"
    "QScrollBar:vertical {"
    "    width: 4px; background: transparent; margin: 0;"
    "}"
    "QScrollBar::handle:vertical {"
    "    background: " + C_BORDER + ";"
    "    border-radius: 2px; min-height: 24px;"
    "}"
    "QScrollBar::handle:vertical:hover { background: " + C_BORDER_HI + "; }"
    "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }"
    "QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: none; }"
)


def _icon_path():
    """Return the absolute path to the plugin icon, or None if not found."""
    this_file = os.path.abspath(__file__)
    icons_dir = os.path.join(os.path.dirname(os.path.dirname(this_file)), "icons")
    path = os.path.join(icons_dir, ICON_FILENAME)
    return path if os.path.isfile(path) else None


def _btn_style(bg, bg_hover, text_color):
    return (
        "QPushButton {"
        "    background-color: " + bg + ";"
        "    border: 1px solid " + bg + ";"
        "    border-radius: 7px;"
        "    color: " + text_color + ";"
        "    font-size: 13px;"
        "    font-weight: 600;"
        "    padding: 9px 0;"
        "}"
        "QPushButton:hover {"
        "    background-color: " + bg_hover + ";"
        "    border-color: " + bg_hover + ";"
        "}"
        "QPushButton:disabled {"
        "    background-color: " + C_BG_RAISED + ";"
        "    border-color: " + C_BORDER + ";"
        "    color: " + C_TEXT_MUTE + ";"
        "}"
    )


# ---------------------------------------------------------------------------
# About dialog
# ---------------------------------------------------------------------------

class AboutDialog(QtWidgets.QDialog):

    def __init__(self, parent=None):
        super(AboutDialog, self).__init__(parent)
        self.setWindowTitle("About Maya Viewer")
        self.setFixedWidth(400)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowContextHelpButtonHint)
        self.setStyleSheet(STYLESHEET)
        self._build()

    def _build(self):
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # -- Teal header band --
        band = QtWidgets.QWidget()
        band.setFixedHeight(72)
        band.setObjectName("HeaderBand")
        band.setStyleSheet(
            "QWidget#HeaderBand { background-color: " + C_TEAL_DIM + ";"
            " border-bottom: 1px solid " + C_TEAL_DARK + "; }"
            " QWidget { background: transparent; border: none; }"
        )
        band_layout = QtWidgets.QVBoxLayout(band)
        band_layout.setContentsMargins(20, 0, 20, 0)
        band_layout.setSpacing(2)

        title_lbl = QtWidgets.QLabel("Maya Viewer")
        title_lbl.setStyleSheet(
            "QLabel { font-size: 18px; font-weight: 700; color: " + C_TEXT_PRI + ";"
            " background: transparent; border: none; }"
        )
        studio_lbl = QtWidgets.QLabel(STUDIO_NAME)
        studio_lbl.setStyleSheet(
            "QLabel { font-size: 11px; color: " + C_TEAL + ";"
            " background: transparent; border: none; }"
        )

        # Icon in the About header
        icon_row = QtWidgets.QHBoxLayout()
        icon_row.setSpacing(12)
        icon_row.setContentsMargins(0, 0, 0, 0)

        icon_lbl = QtWidgets.QLabel()
        icon_lbl.setStyleSheet("QLabel { background: transparent; border: none; }")
        ip = _icon_path()
        if ip:
            pix = QtGui.QPixmap(ip).scaled(40, 40, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            icon_lbl.setFixedSize(pix.size())
            icon_lbl.setPixmap(pix)
        else:
            icon_lbl.setFixedSize(40, 40)
            icon_lbl.setStyleSheet(
                "QLabel { background-color: " + C_TEAL_DEEP + ";"
                " border: 1px solid " + C_TEAL_DARK + "; border-radius: 8px; }"
            )

        text_col = QtWidgets.QVBoxLayout()
        text_col.setSpacing(1)
        text_col.setContentsMargins(0, 0, 0, 0)
        text_col.addWidget(title_lbl)
        text_col.addWidget(studio_lbl)

        icon_row.addWidget(icon_lbl, 0, Qt.AlignVCenter)
        icon_row.addLayout(text_col)
        icon_row.addStretch()

        band_layout.addStretch()
        band_layout.addLayout(icon_row)
        band_layout.addStretch()
        root.addWidget(band)

        # -- Scrollable body --
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea { background-color: " + C_BG_BASE + "; border: none; }")

        body_widget = QtWidgets.QWidget()
        body_widget.setStyleSheet("QWidget { background-color: " + C_BG_BASE + "; }")
        body_layout = QtWidgets.QVBoxLayout(body_widget)
        body_layout.setContentsMargins(20, 16, 20, 16)
        body_layout.setSpacing(12)

        # Description paragraphs
        for text in (DESCRIPTION_1, DESCRIPTION_2):
            lbl = QtWidgets.QLabel(text)
            lbl.setWordWrap(True)
            lbl.setStyleSheet(
                "QLabel { font-size: 12px; color: " + C_TEXT_DIM + ";"
                " line-height: 1.5; background: transparent; }"
            )
            body_layout.addWidget(lbl)

        # Divider
        div = QtWidgets.QFrame()
        div.setFrameShape(QtWidgets.QFrame.HLine)
        div.setStyleSheet(
            "QFrame { background-color: " + C_BORDER + "; border: none; max-height: 1px; }"
        )
        body_layout.addWidget(div)

        # Details card
        card = QtWidgets.QWidget()
        card.setObjectName("AboutCard")
        card.setStyleSheet(
            "QWidget#AboutCard {"
            "    background-color: " + C_BG_INPUT + ";"
            "    border: 1px solid " + C_BORDER + ";"
            "    border-radius: 10px;"
            "}"
        )
        card_layout = QtWidgets.QVBoxLayout(card)
        card_layout.setContentsMargins(0, 0, 0, 0)
        card_layout.setSpacing(0)

        rows = [
            ("Creator", AUTHOR_NAME),
            ("Studio",  STUDIO_NAME),
            ("Website", WEBSITE),
            ("Version", VERSION),
            ("Build",   BUILD),
        ]
        for i, (label, value) in enumerate(rows):
            row_widget = QtWidgets.QWidget()
            row_widget.setStyleSheet("QWidget { background: transparent; }")
            row_layout = QtWidgets.QHBoxLayout(row_widget)
            row_layout.setContentsMargins(16, 12, 16, 12)
            row_layout.setSpacing(12)

            lbl = QtWidgets.QLabel(label)
            lbl.setStyleSheet(
                "QLabel { font-size: 13px; color: " + C_TEXT_SEC + "; background: transparent; }"
            )

            val = QtWidgets.QLineEdit(value)
            val.setReadOnly(True)
            val.setAlignment(Qt.AlignRight)
            val.setStyleSheet(
                "QLineEdit {"
                "    background: transparent;"
                "    border: none;"
                "    color: " + C_TEXT_DIM + ";"
                "    font-size: 13px;"
                "    padding: 0;"
                "    selection-background-color: " + C_TEAL_DIM + ";"
                "}"
                "QLineEdit:focus { border: none; outline: none; }"
            )

            row_layout.addWidget(lbl)
            row_layout.addStretch()
            row_layout.addWidget(val)
            card_layout.addWidget(row_widget)

            # Divider between rows (not after last)
            if i < len(rows) - 1:
                row_div = QtWidgets.QFrame()
                row_div.setFrameShape(QtWidgets.QFrame.HLine)
                row_div.setStyleSheet(
                    "QFrame { background-color: " + C_BORDER + "; border: none;"
                    " max-height: 1px; margin: 0 16px; }"
                )
                card_layout.addWidget(row_div)

        body_layout.addWidget(card)
        body_layout.addStretch()
        scroll.setWidget(body_widget)
        root.addWidget(scroll)

        # -- Footer --
        footer = QtWidgets.QWidget()
        footer.setObjectName("AboutFooter")
        footer.setFixedHeight(52)
        footer.setStyleSheet(
            "QWidget#AboutFooter { background-color: " + C_BG_INPUT + ";"
            " border-top: 1px solid " + C_BORDER + "; }"
        )
        footer_layout = QtWidgets.QHBoxLayout(footer)
        footer_layout.setContentsMargins(16, 0, 16, 0)
        footer_layout.addStretch()

        close_btn = QtWidgets.QPushButton("Close")
        close_btn.setFixedSize(80, 32)
        close_btn.setCursor(QtGui.QCursor(Qt.PointingHandCursor))
        close_btn.setStyleSheet(
            "QPushButton {"
            "    background-color: " + C_BG_RAISED + ";"
            "    border: 1px solid " + C_BORDER_HI + ";"
            "    border-radius: 6px;"
            "    color: " + C_TEXT_SEC + ";"
            "    font-size: 12px;"
            "}"
            "QPushButton:hover {"
            "    border-color: " + C_TEAL_DIM + ";"
            "    color: " + C_TEAL + ";"
            "}"
        )
        close_btn.clicked.connect(self.accept)
        footer_layout.addWidget(close_btn)
        root.addWidget(footer)

        self.setMinimumHeight(460)
        self.setMaximumHeight(600)


# ---------------------------------------------------------------------------
# Main control panel window
# ---------------------------------------------------------------------------

class MayaViewerWindow(QtWidgets.QWidget):

    def __init__(self, parent=None):
        super(MayaViewerWindow, self).__init__(parent)
        self.setObjectName("RFX_MayaViewer_Window")
        self.setFixedWidth(WINDOW_W)
        self.setStyleSheet(STYLESHEET)
        self._build_ui()
        self._refresh_status()

    # -----------------------------------------------------------------------
    # UI construction
    # -----------------------------------------------------------------------

    def _build_ui(self):
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self._make_header())
        root.addWidget(self._make_body())

    def _make_header(self):
        band = QtWidgets.QWidget()
        band.setFixedHeight(68)
        band.setObjectName("HeaderBand")
        band.setStyleSheet(
            "QWidget#HeaderBand { background-color: " + C_TEAL_DIM + ";"
            " border-bottom: 1px solid " + C_TEAL_DARK + "; }"
            " QWidget { background: transparent; border: none; }"
        )
        layout = QtWidgets.QHBoxLayout(band)
        layout.setContentsMargins(16, 0, 12, 0)
        layout.setSpacing(12)

        # Icon
        icon_lbl = QtWidgets.QLabel()
        icon_lbl.setStyleSheet("QLabel { background: transparent; border: none; }")
        ip = _icon_path()
        if ip:
            pix = QtGui.QPixmap(ip).scaled(36, 36, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            icon_lbl.setFixedSize(pix.size())
            icon_lbl.setPixmap(pix)
        else:
            icon_lbl.setFixedSize(36, 36)
            icon_lbl.setStyleSheet(
                "QLabel { background-color: " + C_TEAL_DEEP + ";"
                " border: 1px solid " + C_TEAL_DARK + "; border-radius: 8px; }"
            )
        layout.addWidget(icon_lbl, 0, Qt.AlignVCenter)

        # Title block
        title_block = QtWidgets.QWidget()
        title_block.setStyleSheet("QWidget { background: transparent; border: none; }")
        title_layout = QtWidgets.QVBoxLayout(title_block)
        title_layout.setContentsMargins(0, 0, 0, 0)
        title_layout.setSpacing(1)

        title_lbl = QtWidgets.QLabel("Maya Viewer")
        title_lbl.setStyleSheet(
            "QLabel { font-size: 18px; font-weight: 700; color: " + C_TEXT_PRI + ";"
            " background: transparent; border: none; }"
        )
        studio_lbl = QtWidgets.QLabel(STUDIO_NAME)
        studio_lbl.setStyleSheet(
            "QLabel { font-size: 11px; color: " + C_TEAL + ";"
            " background: transparent; border: none; }"
        )
        title_layout.addStretch()
        title_layout.addWidget(title_lbl)
        title_layout.addWidget(studio_lbl)
        title_layout.addStretch()

        layout.addWidget(title_block)
        layout.addStretch()

        # About "?" button — top-right of header
        about_btn = QtWidgets.QPushButton("?")
        about_btn.setFixedSize(24, 24)
        about_btn.setCursor(QtGui.QCursor(Qt.PointingHandCursor))
        about_btn.setToolTip("About RFX Maya Viewer")
        about_btn.setStyleSheet(
            "QPushButton {"
            "    background: transparent;"
            "    border: 1px solid " + C_TEAL_DARK + ";"
            "    border-radius: 12px;"
            "    color: " + C_TEAL + ";"
            "    font-size: 11px;"
            "    font-weight: 700;"
            "}"
            "QPushButton:hover {"
            "    background-color: " + C_TEAL_DEEP + ";"
            "    border-color: " + C_TEAL + ";"
            "}"
        )
        about_btn.clicked.connect(self._open_about)
        layout.addWidget(about_btn, 0, Qt.AlignVCenter)

        return band

    def _make_body(self):
        body = QtWidgets.QWidget()
        body.setStyleSheet("QWidget { background-color: " + C_BG_BASE + "; }")
        layout = QtWidgets.QVBoxLayout(body)
        layout.setContentsMargins(14, 12, 14, 14)
        layout.setSpacing(8)

        # -- Status row --
        status_row = QtWidgets.QHBoxLayout()
        status_row.setSpacing(7)

        self._status_dot = QtWidgets.QLabel("●")
        self._status_dot.setFixedWidth(14)
        self._status_dot.setAlignment(Qt.AlignVCenter | Qt.AlignLeft)
        self._status_dot.setStyleSheet(
            "QLabel { font-size: 13px; color: " + C_TEXT_MUTE + "; background: transparent; }"
        )
        self._status_lbl = QtWidgets.QLabel("Server stopped")
        self._status_lbl.setStyleSheet(
            "QLabel { font-size: 12px; font-weight: 600; color: " + C_TEXT_DIM + ";"
            " background: transparent; }"
        )
        status_row.addWidget(self._status_dot)
        status_row.addWidget(self._status_lbl)
        status_row.addStretch()
        layout.addLayout(status_row)

        # -- IP info panel (hidden until server starts) --
        self._ip_panel = QtWidgets.QWidget()
        self._ip_panel.setStyleSheet("QWidget { background: transparent; }")
        ip_layout = QtWidgets.QVBoxLayout(self._ip_panel)
        ip_layout.setContentsMargins(0, 2, 0, 0)
        ip_layout.setSpacing(5)

        hint = QtWidgets.QLabel("Enter this IP in the iOS app:")
        hint.setStyleSheet(
            "QLabel { font-size: 11px; color: " + C_TEXT_DIM + "; background: transparent; }"
        )
        ip_layout.addWidget(hint)

        self._ip_fields = []
        for _ in range(3):
            field = QtWidgets.QLineEdit()
            field.setReadOnly(True)
            field.setAlignment(Qt.AlignCenter)
            field.setFixedHeight(30)
            field.setStyleSheet(
                "QLineEdit {"
                "    background-color: " + C_BG_INPUT + ";"
                "    border: 1px solid " + C_BORDER + ";"
                "    border-radius: 6px;"
                "    color: " + C_TEAL + ";"
                "    font-size: 13px;"
                "    font-weight: 600;"
                "    letter-spacing: 0.5px;"
                "}"
            )
            row_widget = QtWidgets.QWidget()
            row_widget.setStyleSheet("QWidget { background: transparent; }")
            row_layout = QtWidgets.QHBoxLayout(row_widget)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.addWidget(field)
            self._ip_fields.append((field, row_widget))
            ip_layout.addWidget(row_widget)
            row_widget.setVisible(False)

        self._ip_panel.setVisible(False)
        layout.addWidget(self._ip_panel)

        # -- Port row --
        port_row = QtWidgets.QHBoxLayout()
        port_row.setSpacing(10)
        port_lbl = QtWidgets.QLabel("Port")
        port_lbl.setStyleSheet(
            "QLabel { font-size: 11px; color: " + C_TEXT_DIM + "; background: transparent; }"
        )
        self._port_spin = QtWidgets.QSpinBox()
        self._port_spin.setRange(1024, 65535)
        self._port_spin.setValue(9001)
        self._port_spin.setFixedHeight(28)
        self._port_spin.setToolTip("WebSocket port the iOS app will connect to")
        port_row.addWidget(port_lbl)
        port_row.addWidget(self._port_spin)
        port_row.addStretch()
        layout.addLayout(port_row)

        # -- Buttons --
        self._start_btn = QtWidgets.QPushButton("Start Server")
        self._start_btn.setFixedHeight(38)
        self._start_btn.setCursor(QtGui.QCursor(Qt.PointingHandCursor))
        self._start_btn.setStyleSheet(
            _btn_style(C_TEAL_DIM, C_TEAL_MID, C_TEAL)
        )
        self._start_btn.clicked.connect(self._on_start)
        layout.addWidget(self._start_btn)

        self._stop_btn = QtWidgets.QPushButton("Stop Server")
        self._stop_btn.setFixedHeight(38)
        self._stop_btn.setCursor(QtGui.QCursor(Qt.PointingHandCursor))
        self._stop_btn.setStyleSheet(
            _btn_style(C_BG_RAISED, C_BG_INPUT, C_TEXT_DIM)
        )
        self._stop_btn.clicked.connect(self._on_stop)
        layout.addWidget(self._stop_btn)

        return body

    # -----------------------------------------------------------------------
    # Actions
    # -----------------------------------------------------------------------

    def _on_start(self):
        try:
            import rfx_mayaviewer as mv
        except Exception as e:
            QtWidgets.QMessageBox.critical(
                self, "RFX Maya Viewer",
                "Could not load rfx_mayaviewer:\n" + str(e)
            )
            return
        port = self._port_spin.value()
        # Disable both buttons immediately to prevent double-clicks
        self._start_btn.setEnabled(False)
        self._stop_btn.setEnabled(False)
        try:
            mv.start_server(port=port)
        except Exception as e:
            QtWidgets.QMessageBox.critical(
                self, "RFX Maya Viewer",
                "Failed to start server on port %d:\n%s" % (port, str(e))
            )
        self._refresh_status()

    def _on_stop(self):
        try:
            import rfx_mayaviewer as mv
            mv.stop_server()
        except Exception as e:
            QtWidgets.QMessageBox.critical(
                self, "RFX Maya Viewer",
                "Failed to stop server:\n" + str(e)
            )
        self._refresh_status()

    def _open_about(self):
        dlg = AboutDialog(parent=self)
        dlg.exec()

    # -----------------------------------------------------------------------
    # Status refresh
    # -----------------------------------------------------------------------

    def _refresh_status(self):
        try:
            import rfx_mayaviewer as mv
            running = bool(mv._SERVER_THREAD and mv._SERVER_THREAD.is_alive())
        except Exception:
            running = False

        if running:
            try:
                import rfx_mayaviewer as mv
                port = mv._PORT
            except Exception:
                port = self._port_spin.value()
            self._status_dot.setStyleSheet(
                "QLabel { font-size: 14px; color: " + C_TEAL + "; background: transparent; }"
            )
            self._status_lbl.setText("Server running  ·  Port %d" % port)
            self._status_lbl.setStyleSheet(
                "QLabel { font-size: 12px; font-weight: 600; color: " + C_TEXT_PRI + ";"
                " background: transparent; }"
            )
            self._start_btn.setEnabled(False)
            self._stop_btn.setStyleSheet(
                _btn_style(C_RED_DIM, C_RED_MID, C_RED)
            )
            self._stop_btn.setEnabled(True)
            self._port_spin.setEnabled(False)
            self._show_ips(port)
        else:
            self._status_dot.setStyleSheet(
                "QLabel { font-size: 14px; color: " + C_TEXT_MUTE + "; background: transparent; }"
            )
            self._status_lbl.setText("Server stopped")
            self._status_lbl.setStyleSheet(
                "QLabel { font-size: 12px; font-weight: 600; color: " + C_TEXT_DIM + ";"
                " background: transparent; }"
            )
            self._start_btn.setEnabled(True)
            self._stop_btn.setStyleSheet(
                _btn_style(C_BG_RAISED, C_BG_INPUT, C_TEXT_DIM)
            )
            self._stop_btn.setEnabled(False)
            self._port_spin.setEnabled(True)
            self._hide_ips()

    def _show_ips(self, port):
        try:
            import rfx_mayaviewer as mv
            ips = mv._get_local_ips()
            if not ips:
                ips = ["127.0.0.1"]
        except Exception:
            ips = ["127.0.0.1"]

        self._ip_panel.setVisible(True)
        for i, (field, row_widget) in enumerate(self._ip_fields):
            if i < len(ips):
                field.setText(ips[i])
                row_widget.setVisible(True)
            else:
                row_widget.setVisible(False)

        QtCore.QTimer.singleShot(0, self.adjustSize)

    def _hide_ips(self):
        self._ip_panel.setVisible(False)
        for _, row_widget in self._ip_fields:
            row_widget.setVisible(False)
        QtCore.QTimer.singleShot(0, self.adjustSize)


# ---------------------------------------------------------------------------
# Window launcher
# ---------------------------------------------------------------------------

_window_instance = None


def _get_maya_main_window():
    ptr = omui.MQtUtil.mainWindow()
    if ptr:
        return shiboken6.wrapInstance(int(ptr), QtWidgets.QWidget)
    return None


def launch():
    """Open the Maya Viewer control panel. Safe to call multiple times."""
    global _window_instance

    if _window_instance is not None:
        try:
            if _window_instance.isVisible():
                _window_instance._refresh_status()
                _window_instance.raise_()
                _window_instance.activateWindow()
                return _window_instance
            # Window was closed but C++ object still alive — release it properly
            _window_instance.deleteLater()
        except RuntimeError:
            pass  # C++ object already destroyed by Qt
        _window_instance = None

    parent = _get_maya_main_window()
    win = MayaViewerWindow(parent=parent)
    win.setWindowFlags(win.windowFlags() | Qt.Tool)
    win.setWindowTitle(WINDOW_TITLE)
    win.show()
    win.raise_()
    win.activateWindow()

    _window_instance = win
    return win
