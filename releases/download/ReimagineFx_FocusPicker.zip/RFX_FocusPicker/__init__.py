"""
RFX_FocusPicker - Maya Arnold camera focus tool.
Import and call browser.launch() to open the tool.
"""
from .browser import launch

__all__ = ["launch"]
