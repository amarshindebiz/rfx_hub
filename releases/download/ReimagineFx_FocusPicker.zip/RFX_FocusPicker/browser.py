"""
RFX_FocusPicker - browser.py
============================
Cupertino-dark PySide6 interface for the Arnold focus picker.
All Maya attribute reads and writes delegate to core.py.

Requires: Maya 2025+, PySide6, shiboken6, Arnold for Maya (MtoA)
"""
from __future__ import annotations

import logging
import os

import maya.cmds as cmds
from PySide6 import QtCore, QtGui, QtWidgets
import shiboken6


PLUGIN_NAME = "RFX Focus Picker"
PLUGIN_VERSION = "1.1"
STUDIO_NAME = "Reimagine Fx"
AUTHOR_NAME = "Amar Shinde"
WEBSITE = "www.reimaginefx.com"
EMAIL = "reimaginefx@gmail.com"
COPYRIGHT_YEAR = "2026"
DESCRIPTION = (
    "Set Arnold camera focus directly from the Maya viewport, with live "
    "depth-of-field and aperture controls."
)


C_BG = "#151517"
C_HEADER = "#101012"
C_PANEL = "#1C1C1E"
C_CARD = "#242426"
C_CARD_HOVER = "#2C2C2E"
C_FIELD = "#303033"
C_FIELD_FOCUS = "#36363A"
C_BORDER = "#38383C"
C_HAIRLINE = "#303034"
C_ACCENT = "#0A84FF"
C_ACCENT_HOVER = "#409CFF"
C_ACCENT_SOFT = "#153C63"
C_TEXT = "#F5F5F7"
C_TEXT_SECONDARY = "#A1A1A6"
C_TEXT_MUTED = "#6E6E73"
C_GREEN = "#30D158"
C_ORANGE = "#FF9F0A"
C_RED = "#FF453A"
VALUE_FIELD_WIDTH = 92


try:
    from rfx_ui_scale import apply_maya_ui_scale, maya_readability_scale
except Exception:
    def apply_maya_ui_scale(widget, scale=None, scale_window=True):
        return 1.0

    def maya_readability_scale(scale=None, widget=None):
        return 1.0

try:
    import maya.OpenMayaUI as omui
    _MUI_OK = True
except ImportError:
    _MUI_OK = False


log = logging.getLogger(__name__)
if not log.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter("[%(name)s] %(levelname)s: %(message)s"))
    log.addHandler(_handler)
log.setLevel(logging.INFO)


def _get_icons_dir():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons")


def _icon_path():
    return os.path.join(_get_icons_dir(), "RFX_focuspicker_icon.png")


def _maya_main_window():
    if not _MUI_OK:
        return None
    try:
        ptr = omui.MQtUtil.mainWindow()
        if ptr is None:
            return None
        return shiboken6.wrapInstance(int(ptr), QtWidgets.QWidget)
    except Exception:
        return None


def _focuspicker_ui_scale(widget=None):
    """Return the compact 4K scale tuned for the Focus Picker family."""
    try:
        if cmds.optionVar(exists="rfxFocusPickerUiScale"):
            value = float(cmds.optionVar(query="rfxFocusPickerUiScale"))
            return max(1.0, min(2.0, value))
    except Exception:
        pass
    try:
        return max(1.0, min(1.6, float(maya_readability_scale(widget=widget))))
    except Exception:
        return 1.0


def _label(text, color=C_TEXT_SECONDARY, size=11, weight=400):
    label = QtWidgets.QLabel(text)
    label.setStyleSheet(
        "QLabel { background: transparent; color: " + color + "; "
        "font-size: " + str(size) + "px; font-weight: " + str(weight) + "; }"
    )
    return label


def _about_label(text, color=C_TEXT_SECONDARY, size=11, weight=400):
    """Create an About label whose integer QSS font size renders in Maya."""
    label = QtWidgets.QLabel(text)
    text_weight = "bold" if int(weight) >= 600 else "normal"
    style = (
        "QLabel { background: transparent; color: " + color + "; font-size: " +
        str(int(size)) + "px; font-weight: " + text_weight + "; }"
    )
    label.setStyleSheet(style)
    label.setProperty("_rfx_about_label_style", style)
    return label


def _restore_fixed_label_styles(widget):
    """Restore authored integer font sizes after Maya high-DPI scaling."""
    for label in widget.findChildren(QtWidgets.QLabel):
        style = label.property("_rfx_about_label_style")
        if style:
            label.setStyleSheet(style)


def _event_global_x(event):
    try:
        return int(event.globalPosition().x())
    except Exception:
        return int(event.globalPos().x())


_STYLESHEET = (
    "QWidget { background-color: " + C_BG + "; color: " + C_TEXT + ";"
    " font-family: 'Inter', 'Segoe UI', Arial, sans-serif; font-size: 11px;"
    " border: none; outline: none; }"
    "QLabel { background: transparent; }"
    "QComboBox { background-color: " + C_FIELD + "; color: " + C_TEXT + ";"
    " border: 1px solid " + C_BORDER + "; border-radius: 8px; padding: 5px 10px;"
    " min-height: 24px; }"
    "QComboBox:hover { border-color: #505056; }"
    "QComboBox:focus { border-color: " + C_ACCENT + "; }"
    "QComboBox::drop-down { border: none; width: 22px; }"
    "QComboBox QAbstractItemView { background-color: " + C_CARD + "; color: " + C_TEXT + ";"
    " selection-background-color: " + C_ACCENT_SOFT + "; border: 1px solid " + C_BORDER + ";"
    " padding: 4px; }"
    "QScrollArea { background: transparent; border: none; }"
    "QScrollBar:vertical { background: transparent; width: 7px; margin: 4px 0; }"
    "QScrollBar::handle:vertical { background: #45454A; border-radius: 3px; min-height: 24px; }"
    "QScrollBar::handle:vertical:hover { background: #5A5A60; }"
    "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }"
    "QToolTip { background-color: " + C_CARD + "; color: " + C_TEXT + ";"
    " border: 1px solid " + C_BORDER + "; padding: 6px 9px; border-radius: 6px; }"
)


class ToggleSwitch(QtWidgets.QAbstractButton):
    def __init__(self, parent=None):
        super(ToggleSwitch, self).__init__(parent)
        self.setCheckable(True)
        self.setCursor(QtCore.Qt.PointingHandCursor)
        self.setFixedSize(36, 20)

    def sizeHint(self):
        return QtCore.QSize(36, 20)

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setPen(QtCore.Qt.NoPen)
        track = self.rect().adjusted(1, 1, -1, -1)
        painter.setBrush(QtGui.QColor(C_ACCENT if self.isChecked() else "#48484D"))
        painter.drawRoundedRect(track, track.height() / 2.0, track.height() / 2.0)
        diameter = track.height() - 4
        x_pos = track.right() - diameter - 2 if self.isChecked() else track.left() + 2
        knob = QtCore.QRectF(float(x_pos), float(track.top() + 2), float(diameter), float(diameter))
        painter.setBrush(QtGui.QColor("#FFFFFF"))
        painter.drawEllipse(knob)


class Card(QtWidgets.QFrame):
    def __init__(self, parent=None, elevated=False):
        super(Card, self).__init__(parent)
        bg = C_CARD if elevated else C_PANEL
        self.setStyleSheet(
            "QFrame { background-color: " + bg + "; border: 1px solid " + C_HAIRLINE + ";"
            " border-radius: 14px; } QFrame QLabel { border: none; }"
        )


class MayaDragSpinBox(QtWidgets.QDoubleSpinBox):
    """Large Maya-style value field with direct horizontal scrubbing."""

    dragStarted = QtCore.Signal()
    dragFinished = QtCore.Signal()

    def __init__(self, value=0.0, min_val=0.0, max_val=99999.0,
                 step=0.1, decimals=4, parent=None):
        super(MayaDragSpinBox, self).__init__(parent)
        self.setLocale(QtCore.QLocale(QtCore.QLocale.C))
        self.setDecimals(decimals)
        self.setRange(min_val, max_val)
        self.setSingleStep(step)
        self.setValue(value)
        self.setButtonSymbols(QtWidgets.QAbstractSpinBox.NoButtons)
        self.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        self.setMinimumHeight(30)
        self.setCursor(QtCore.Qt.ArrowCursor)
        self.lineEdit().setCursor(QtCore.Qt.IBeamCursor)

        self._base_step = step
        self._dragging = False
        self._drag_start_x = 0
        self._drag_start_value = 0.0
        self._drag_label = None
        self._app_filter = None
        self._normal_style = self._make_style(C_BORDER, C_FIELD)
        self._drag_style = self._make_style(C_ACCENT, C_FIELD_FOCUS)
        self.setStyleSheet(self._normal_style)
        self.installEventFilter(self)
        self.lineEdit().installEventFilter(self)
        self.setToolTip("Drag horizontally to adjust. Click to type an exact value.")

    def _make_style(self, border, background):
        return (
            "QDoubleSpinBox { background-color: " + background + "; color: " + C_TEXT + ";"
            " border: 1px solid " + border + "; border-radius: 8px; padding: 3px 10px;"
            " font-family: 'JetBrains Mono', Consolas, monospace; font-size: 13px;"
            " font-weight: 600; selection-background-color: " + C_ACCENT + "; }"
        )

    def set_drag_label(self, label):
        self._drag_label = label
        label.setCursor(QtCore.Qt.SizeHorCursor)
        label.setToolTip("Drag horizontally to change the value")
        label.installEventFilter(self)

    def _begin_drag(self, global_x):
        if self._dragging:
            return
        self._dragging = True
        self._drag_start_x = global_x
        self._drag_start_value = self.value()
        self.setStyleSheet(self._drag_style)
        QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.SizeHorCursor)
        self._app_filter = self._GlobalDragFilter(self)
        app = QtWidgets.QApplication.instance()
        if app is not None:
            app.installEventFilter(self._app_filter)
        self.dragStarted.emit()

    def _update_drag(self, global_x, modifiers):
        pixels = global_x - self._drag_start_x
        multiplier = 1.0
        if modifiers & QtCore.Qt.ShiftModifier:
            multiplier = 10.0
        elif modifiers & QtCore.Qt.ControlModifier:
            multiplier = 0.1
        value = self._drag_start_value + pixels * self._base_step * multiplier
        self.setValue(max(self.minimum(), min(self.maximum(), value)))

    def _finish_drag(self):
        if not self._dragging:
            return
        self._dragging = False
        self.setStyleSheet(self._normal_style)
        QtWidgets.QApplication.restoreOverrideCursor()
        app = QtWidgets.QApplication.instance()
        if app is not None and self._app_filter is not None:
            app.removeEventFilter(self._app_filter)
        self._app_filter = None
        self.dragFinished.emit()

    def eventFilter(self, obj, event):
        event_type = event.type()
        is_label = obj is self._drag_label
        is_field = obj is self or obj is self.lineEdit()

        if event_type == QtCore.QEvent.MouseButtonPress:
            if is_label and event.button() == QtCore.Qt.LeftButton:
                self._begin_drag(_event_global_x(event))
                return True
            if is_field and event.button() == QtCore.Qt.MiddleButton:
                self._begin_drag(_event_global_x(event))
                return True
        elif event_type == QtCore.QEvent.MouseMove and self._dragging:
            self._update_drag(_event_global_x(event), event.modifiers())
            return True
        elif event_type == QtCore.QEvent.MouseButtonRelease and self._dragging:
            if ((is_label and event.button() == QtCore.Qt.LeftButton) or
                    (is_field and event.button() == QtCore.Qt.MiddleButton)):
                self._finish_drag()
                return True

        return super(MayaDragSpinBox, self).eventFilter(obj, event)

    class _GlobalDragFilter(QtCore.QObject):
        def __init__(self, owner):
            super(MayaDragSpinBox._GlobalDragFilter, self).__init__()
            self._owner = owner

        def eventFilter(self, obj, event):
            if event.type() == QtCore.QEvent.MouseMove and self._owner._dragging:
                self._owner._update_drag(_event_global_x(event), event.modifiers())
            elif event.type() == QtCore.QEvent.MouseButtonRelease and self._owner._dragging:
                self._owner._finish_drag()
            return False


class AboutDialog(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super(AboutDialog, self).__init__(parent)
        self.setObjectName("RFXFocusPickerAbout")
        self.setWindowTitle("About Focus Picker")
        self.setFixedSize(360, 220)
        self.setWindowFlags(
            QtCore.Qt.Dialog |
            QtCore.Qt.WindowCloseButtonHint |
            QtCore.Qt.MSWindowsFixedSizeDialogHint
        )
        self.setStyleSheet(_STYLESHEET)
        self._build()
        apply_maya_ui_scale(
            self, scale=_focuspicker_ui_scale(self), scale_window=True)

    def _restore_about_styles(self):
        """Obsolete: scale_stylesheet now emits integer px, so scaled QSS
        font sizes render in Maya and no restore pass is needed."""
        pass

    def _build(self):
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        header = QtWidgets.QWidget()
        header.setObjectName("RFXFocusPickerAboutHeader")
        header.setFixedHeight(54)
        header.setStyleSheet(
            "QWidget#RFXFocusPickerAboutHeader { background-color: " + C_HEADER + ";"
            " border-bottom: 1px solid " + C_HAIRLINE + "; }"
        )
        header_layout = QtWidgets.QHBoxLayout(header)
        header_layout.setContentsMargins(12, 8, 12, 8)
        header_layout.setSpacing(9)

        icon = QtWidgets.QLabel()
        icon.setFixedSize(36, 36)
        pixmap = QtGui.QPixmap(_icon_path())
        if not pixmap.isNull():
            icon.setPixmap(pixmap.scaled(
                36, 36, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation))
        icon.setAlignment(QtCore.Qt.AlignCenter)
        header_layout.addWidget(icon)

        brand_copy = QtWidgets.QVBoxLayout()
        brand_copy.setContentsMargins(0, 0, 0, 0)
        brand_copy.setSpacing(0)
        title = _about_label("Focus Picker", C_TEXT, 15, 700)
        title.setFixedHeight(18)
        title.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        subtitle = _about_label("Reimagine Fx", C_ACCENT_HOVER, 10, 700)
        subtitle.setFixedHeight(18)
        subtitle.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        brand_copy.addWidget(title)
        brand_copy.addWidget(subtitle)
        header_layout.addLayout(brand_copy, 1)
        root.addWidget(header)

        body = QtWidgets.QWidget()
        body_layout = QtWidgets.QVBoxLayout(body)
        body_layout.setContentsMargins(12, 8, 12, 8)
        body_layout.setSpacing(6)

        description = _about_label(DESCRIPTION, C_TEXT_SECONDARY, 11, 400)
        description.setWordWrap(True)
        description.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        body_layout.addWidget(description)

        info = Card(elevated=True)
        info_root = QtWidgets.QVBoxLayout(info)
        info_root.setContentsMargins(10, 8, 10, 8)
        info_root.setSpacing(0)
        info_layout = QtWidgets.QGridLayout()
        info_layout.setContentsMargins(0, 0, 0, 0)
        info_layout.setHorizontalSpacing(12)
        info_layout.setVerticalSpacing(3)
        rows = [
            ("CREATOR", AUTHOR_NAME),
            ("STUDIO", STUDIO_NAME),
            ("WEB", WEBSITE),
            ("EMAIL", EMAIL),
        ]
        for row, values in enumerate(rows):
            key = _about_label(values[0], C_TEXT_MUTED, 9, 700)
            val = _about_label(values[1], C_TEXT, 10, 600)
            val.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
            info_layout.addWidget(key, row, 0)
            info_layout.addWidget(val, row, 1)
        info_layout.setColumnStretch(1, 1)
        info_root.addLayout(info_layout)
        body_layout.addWidget(info)
        root.addWidget(body)

        footer = QtWidgets.QWidget()
        footer.setFixedHeight(34)
        footer.setStyleSheet(
            "background-color: " + C_HEADER + "; border-top: 1px solid " + C_HAIRLINE + ";"
        )
        footer_layout = QtWidgets.QHBoxLayout(footer)
        footer_layout.setContentsMargins(12, 5, 12, 5)
        footer_layout.setSpacing(8)
        copyright_label = _about_label(
            "Copyright " + COPYRIGHT_YEAR + " " + STUDIO_NAME, C_TEXT_MUTED, 8, 400)
        footer_layout.addWidget(copyright_label)
        footer_layout.addStretch()

        close_button = QtWidgets.QPushButton("Done")
        close_button.setFixedSize(72, 24)
        close_button.setCursor(QtCore.Qt.PointingHandCursor)
        close_style = (
            "QPushButton { background-color: " + C_ACCENT + "; color: white; border: none;"
            " border-radius: 7px; font-size: 10px; font-weight: 700; }"
            "QPushButton:hover { background-color: " + C_ACCENT_HOVER + "; }"
        )
        close_button.setStyleSheet(close_style)
        close_button.setProperty("_rfx_about_button_style", close_style)
        close_button.clicked.connect(self.accept)
        footer_layout.addWidget(close_button)
        root.addWidget(footer)


class FocusPickerWindow(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super(FocusPickerWindow, self).__init__(parent)
        self.setObjectName("RFX_FocusPickerWindow")
        self.setWindowTitle(PLUGIN_NAME + "  v" + PLUGIN_VERSION)
        self.setWindowFlags(
            QtCore.Qt.Window |
            QtCore.Qt.WindowCloseButtonHint |
            QtCore.Qt.WindowMinimizeButtonHint
        )
        self.setMinimumSize(350, 300)
        self.resize(370, 310)
        self.setStyleSheet(_STYLESHEET)
        self._core = None
        self._about_dialog = None
        self._load_core()
        self._build_ui()
        self._populate_cameras()
        ui_scale = _focuspicker_ui_scale(self)
        # Scale the compact authored window consistently across Maya screens.
        # rescaling (attach_screen_watcher in launch) can restore it exactly.
        apply_maya_ui_scale(self, scale=ui_scale, scale_window=True)
        _restore_fixed_label_styles(self)
        self._cam_combo.setFixedHeight(int(round(26.0 * ui_scale)))

    def _load_core(self):
        try:
            from . import core as core_module
            self._core = core_module
        except ImportError:
            try:
                import core as core_module
                self._core = core_module
            except ImportError:
                log.error("RFX_FocusPicker: could not import core.py")

    def _build_ui(self):
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self._build_header())

        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        content = QtWidgets.QWidget()
        content.setStyleSheet("background-color: " + C_BG + ";")
        layout = QtWidgets.QVBoxLayout(content)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(7)
        layout.addWidget(self._build_camera_card())
        layout.addWidget(self._build_focus_card())
        layout.addWidget(self._build_optics_card())
        scroll.setWidget(content)
        root.addWidget(scroll, 1)
        root.addWidget(self._build_status_bar())

    def _build_header(self):
        header = QtWidgets.QWidget()
        header.setObjectName("RFXFocusHeader")
        header.setFixedHeight(54)
        header.setStyleSheet(
            "QWidget#RFXFocusHeader { background-color: " + C_HEADER + ";"
            " border-bottom: 1px solid " + C_HAIRLINE + "; }"
        )
        layout = QtWidgets.QHBoxLayout(header)
        layout.setContentsMargins(12, 8, 12, 8)
        layout.setSpacing(9)

        icon = QtWidgets.QLabel()
        icon.setFixedSize(36, 36)
        pixmap = QtGui.QPixmap(_icon_path())
        if not pixmap.isNull():
            icon.setPixmap(pixmap.scaled(
                36, 36, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation))
        icon.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(icon)

        identity = QtWidgets.QVBoxLayout()
        identity.setSpacing(0)
        identity.setContentsMargins(0, 0, 0, 0)
        title = _about_label("Focus Picker", C_TEXT, 15, 700)
        title.setFixedHeight(18)
        title.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        subtitle = _about_label("Reimagine Fx", C_ACCENT_HOVER, 10, 700)
        subtitle.setFixedHeight(18)
        subtitle.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        identity.addWidget(title)
        identity.addWidget(subtitle)
        layout.addLayout(identity)
        layout.addStretch()

        about_button = QtWidgets.QPushButton("About")
        about_button.setFixedSize(52, 22)
        about_button.setCursor(QtCore.Qt.PointingHandCursor)
        about_button.setStyleSheet(
            "QPushButton { background-color: " + C_CARD + "; color: " + C_TEXT_SECONDARY + ";"
            " border: 1px solid " + C_BORDER + "; border-radius: 12px; font-weight: 600; }"
            "QPushButton:hover { color: " + C_TEXT + "; border-color: " + C_ACCENT + "; }"
        )
        about_button.clicked.connect(self._on_about)
        layout.addWidget(about_button)
        return header

    def _section_heading(self, eyebrow, title, description=None):
        box = QtWidgets.QVBoxLayout()
        box.setSpacing(3)
        eye = _label(eyebrow.upper(), C_ACCENT_HOVER, 9, 700)
        eye.setStyleSheet(eye.styleSheet() + " QLabel { letter-spacing: 1px; }")
        box.addWidget(eye)
        box.addWidget(_label(title, C_TEXT, 14, 650))
        if description:
            desc = _label(description, C_TEXT_MUTED, 10, 400)
            desc.setWordWrap(True)
            box.addWidget(desc)
        return box

    def _build_camera_card(self):
        card = Card()
        row = QtWidgets.QHBoxLayout(card)
        row.setContentsMargins(10, 8, 10, 8)
        row.setSpacing(6)
        row.addWidget(_about_label("CAMERA", C_ACCENT_HOVER, 10, 700))
        self._cam_combo = QtWidgets.QComboBox()
        self._cam_combo.setFixedHeight(26)
        self._cam_combo.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self._cam_combo.currentIndexChanged.connect(self._on_camera_changed)
        row.addWidget(self._cam_combo, 1)

        buttons = [
            ("+", "Create a new camera", self._on_add_camera),
            ("-", "Delete the selected camera", self._on_remove_camera),
            ("R", "Refresh the camera list", self._on_refresh),
        ]
        for text, tooltip, callback in buttons:
            button = QtWidgets.QPushButton(text)
            button.setFixedSize(26, 26)
            button.setToolTip(tooltip)
            button.setCursor(QtCore.Qt.PointingHandCursor)
            button.setStyleSheet(
                "QPushButton { background-color: " + C_FIELD + "; color: " + C_TEXT_SECONDARY + ";"
                " border: 1px solid " + C_BORDER + "; border-radius: 13px; font-weight: 700; }"
                "QPushButton:hover { background-color: " + C_CARD_HOVER + "; color: " + C_ACCENT_HOVER + ";"
                " border-color: " + C_ACCENT + "; }"
            )
            button.clicked.connect(callback)
            row.addWidget(button)
        return card

    def _build_focus_card(self):
        card = Card(elevated=True)
        row = QtWidgets.QHBoxLayout(card)
        row.setContentsMargins(10, 8, 10, 8)
        row.setSpacing(6)
        focus_label = _about_label("DISTANCE", C_TEXT_SECONDARY, 10, 700)
        row.addWidget(focus_label)

        self._focus_spin = MayaDragSpinBox(
            value=0.0, min_val=0.0, max_val=99999.0, step=0.1, decimals=4)
        self._focus_spin.setFixedWidth(VALUE_FIELD_WIDTH)
        self._focus_spin.set_drag_label(focus_label)
        self._focus_spin.valueChanged.connect(self._on_focus_changed)
        row.addWidget(self._focus_spin)

        self._pick_btn = QtWidgets.QPushButton("PICK FOCUS IN VIEWPORT")
        self._pick_btn.setFixedHeight(30)
        self._pick_btn.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self._pick_btn.setCursor(QtCore.Qt.PointingHandCursor)
        self._pick_btn.setToolTip("Click, then choose any visible surface. Press Esc to cancel.")
        self._pick_btn.setStyleSheet(
            "QPushButton { background-color: " + C_ACCENT + "; color: white; border: none;"
            " border-radius: 9px; font-size: 11px; font-weight: 750; }"
            "QPushButton:hover { background-color: " + C_ACCENT_HOVER + "; }"
            "QPushButton:pressed { background-color: #006EDC; padding-top: 2px; }"
        )
        self._pick_btn.clicked.connect(self._on_pick_clicked)
        row.addWidget(self._pick_btn, 1)
        return card

    def _build_optics_card(self):
        card = Card()
        layout = QtWidgets.QVBoxLayout(card)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(7)
        layout.addWidget(_about_label("LENS CONTROLS", C_ACCENT_HOVER, 10, 700))

        controls_row = QtWidgets.QHBoxLayout()
        controls_row.setSpacing(6)
        controls_row.addWidget(_about_label("DOF", C_TEXT, 11, 600))
        self._dof_switch = ToggleSwitch()
        self._dof_switch.setToolTip("Toggle Arnold depth of field")
        self._dof_switch.toggled.connect(self._on_dof_changed)
        controls_row.addWidget(self._dof_switch)
        controls_row.addStretch()
        focal_label = _about_label("FOCAL", C_TEXT_SECONDARY, 9, 700)
        controls_row.addWidget(focal_label)
        self._focal_spin = MayaDragSpinBox(
            value=35.0, min_val=1.0, max_val=10000.0, step=1.0, decimals=1)
        self._focal_spin.setFixedWidth(62)
        self._focal_spin.set_drag_label(focal_label)
        self._focal_spin.setToolTip("Camera focal length in millimeters")
        self._focal_spin.valueChanged.connect(self._on_focal_length_changed)
        controls_row.addWidget(self._focal_spin)
        controls_row.addStretch()
        aperture_label = _about_label("APERTURE", C_TEXT_SECONDARY, 10, 700)
        controls_row.addWidget(aperture_label)
        self._aperture_spin = MayaDragSpinBox(
            value=0.1, min_val=0.0, max_val=100.0, step=0.01, decimals=4)
        self._aperture_spin.setFixedWidth(76)
        self._aperture_spin.set_drag_label(aperture_label)
        self._aperture_spin.valueChanged.connect(self._on_aperture_changed)
        controls_row.addWidget(self._aperture_spin)
        layout.addLayout(controls_row)
        return card

    def _build_status_bar(self):
        bar = QtWidgets.QWidget()
        bar.setFixedHeight(24)
        bar.setStyleSheet(
            "background-color: " + C_HEADER + "; border-top: 1px solid " + C_HAIRLINE + ";"
        )
        layout = QtWidgets.QHBoxLayout(bar)
        layout.setContentsMargins(10, 0, 10, 0)
        layout.setSpacing(6)
        self._status_dot = QtWidgets.QLabel()
        self._status_dot.setFixedSize(8, 8)
        self._status_dot.setStyleSheet(
            "background-color: " + C_GREEN + "; border-radius: 4px;"
        )
        layout.addWidget(self._status_dot)
        self._status_lbl = _about_label("Ready", C_TEXT_SECONDARY, 9, 500)
        layout.addWidget(self._status_lbl)
        layout.addStretch()
        version = _about_label("ARNOLD  |  v" + PLUGIN_VERSION, C_TEXT_MUTED, 8, 700)
        layout.addWidget(version)
        return bar

    def _populate_cameras(self, keep_current=False):
        previous_shape = self._current_camera()[1] if keep_current else None
        self._cam_combo.blockSignals(True)
        self._cam_combo.clear()
        cameras = self._core.get_all_cameras() if self._core else []

        if cameras:
            restore_index = 0
            for index, camera in enumerate(cameras):
                transform, shape = camera
                self._cam_combo.addItem(transform, userData=(transform, shape))
                if previous_shape and shape == previous_shape:
                    restore_index = index
            self._cam_combo.blockSignals(False)
            self._cam_combo.setCurrentIndex(restore_index)
            self._on_camera_changed(restore_index)
        else:
            self._cam_combo.addItem("No render cameras found")
            self._cam_combo.blockSignals(False)
            self._set_status("Create or select a render camera", "warn")

    def _current_camera(self):
        data = self._cam_combo.currentData()
        if isinstance(data, tuple):
            return data
        return (None, None)

    def _on_camera_changed(self, index):
        transform, shape = self._current_camera()
        if not shape:
            return
        if self._core:
            self._core.switch_viewport_to_camera(transform)
            self._core.set_active_camera(transform, shape)
            self._load_camera_values(shape)
            self._core.install_sync_callback(self._on_maya_attr_changed)
        self._set_status("Active camera: " + transform)

    def _on_add_camera(self):
        try:
            result = cmds.camera(name="RFX_Camera", focalLength=35, centerOfInterest=5)
            new_transform = result[0]
            new_shape = result[1]
            self._populate_cameras(keep_current=False)
            for index in range(self._cam_combo.count()):
                data = self._cam_combo.itemData(index)
                if isinstance(data, tuple) and data[1] == new_shape:
                    self._cam_combo.setCurrentIndex(index)
                    break
            self._set_status("Created camera: " + new_transform)
        except Exception as exc:
            self._set_status("Create camera failed: " + str(exc), "err")

    def _on_remove_camera(self):
        transform, shape = self._current_camera()
        if not transform:
            self._set_status("No camera selected", "warn")
            return
        reply = QtWidgets.QMessageBox.question(
            self, "Delete Camera", "Delete camera '" + transform + "' from the scene?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.No)
        if reply != QtWidgets.QMessageBox.Yes:
            return
        try:
            if self._core:
                self._core._kill_sync_jobs()
            cmds.delete(transform)
            self._populate_cameras(keep_current=False)
            self._set_status("Deleted camera: " + transform)
        except Exception as exc:
            self._set_status("Delete failed: " + str(exc), "err")

    def _on_refresh(self):
        self._populate_cameras(keep_current=True)
        self._set_status("Camera list refreshed")

    def _on_dof_changed(self, checked):
        shape = self._current_camera()[1]
        if not shape or not self._core:
            return
        value = 1 if bool(checked) else 0
        if not self._core.safe_set(shape, "aiEnableDOF", value, "RFX_FP_dof"):
            self._core.safe_set(shape, "depthOfField", value, "RFX_FP_dof")
        self._set_status("Depth of field " + ("enabled" if value else "disabled"))

    def _on_focus_changed(self, value):
        shape = self._current_camera()[1]
        if not shape or not self._core:
            return
        if not self._core.safe_set(shape, "aiFocusDistance", value, "RFX_FP_focus"):
            self._core.safe_set(shape, "focusDistance", value, "RFX_FP_focus")
        self._set_status("Focus distance: {:.4f}".format(value))

    def _on_aperture_changed(self, value):
        shape = self._current_camera()[1]
        if not shape or not self._core:
            return
        self._core.safe_set(shape, "aiApertureSize", value, "RFX_FP_aperture")
        self._set_status("Aperture: {:.4f}".format(value))

    def _on_focal_length_changed(self, value):
        shape = self._current_camera()[1]
        if not shape or not self._core:
            return
        self._core.safe_set(shape, "focalLength", value, "RFX_FP_focal_length")
        self._set_status("Focal length: {:.1f} mm".format(value))

    def _on_pick_clicked(self):
        shape = self._current_camera()[1]
        if not shape:
            self._set_status("Select a render camera first", "warn")
            return
        self._set_status("Click a surface in the viewport or press Esc")
        if self._core:
            self._core.start_pick(shape, self._on_pick_result)

    def _on_pick_result(self, distance):
        self._focus_spin.blockSignals(True)
        self._focus_spin.setValue(distance)
        self._focus_spin.blockSignals(False)
        self._set_status("Focus set to {:.4f}".format(distance))

    def _on_about(self):
        try:
            if self._about_dialog is not None and shiboken6.isValid(self._about_dialog):
                self._about_dialog.show()
                self._about_dialog.raise_()
                self._about_dialog.activateWindow()
                return
        except Exception:
            pass
        self._about_dialog = AboutDialog(parent=self)
        self._about_dialog.show()

    def _load_camera_values(self, shape):
        if not shape or not self._core:
            return
        dof_attr = "aiEnableDOF" if self._core.attr_exists(shape, "aiEnableDOF") else "depthOfField"
        dof_value = bool(self._core.safe_get(shape, dof_attr, 0.0))
        self._dof_switch.blockSignals(True)
        self._dof_switch.setChecked(dof_value)
        self._dof_switch.blockSignals(False)
        self._dof_switch.update()

        focus_attr = "aiFocusDistance" if self._core.attr_exists(shape, "aiFocusDistance") else "focusDistance"
        focus_value = self._core.safe_get(shape, focus_attr, 100.0)
        self._focus_spin.blockSignals(True)
        self._focus_spin.setValue(focus_value)
        self._focus_spin.blockSignals(False)

        aperture_value = self._core.safe_get(shape, "aiApertureSize", 0.1)
        self._aperture_spin.blockSignals(True)
        self._aperture_spin.setValue(aperture_value)
        self._aperture_spin.blockSignals(False)

        focal_value = self._core.safe_get(shape, "focalLength", 35.0)
        self._focal_spin.blockSignals(True)
        self._focal_spin.setValue(focal_value)
        self._focal_spin.blockSignals(False)

    def _set_status(self, message, level="ok"):
        self._status_lbl.setText(message)
        colors = {"ok": C_GREEN, "warn": C_ORANGE, "err": C_RED}
        self._status_dot.setStyleSheet(
            "background-color: " + colors.get(level, C_GREEN) + "; border-radius: 4px;"
        )

    def _on_maya_attr_changed(self, attr_name, value):
        try:
            if attr_name == "aiEnableDOF":
                self._dof_switch.blockSignals(True)
                self._dof_switch.setChecked(bool(value))
                self._dof_switch.blockSignals(False)
                self._dof_switch.update()
                self._set_status("Depth of field " + ("enabled" if value else "disabled"))
            elif attr_name == "aiFocusDistance":
                self._focus_spin.blockSignals(True)
                self._focus_spin.setValue(float(value))
                self._focus_spin.blockSignals(False)
                self._set_status("Focus distance: {:.4f}".format(float(value)))
            elif attr_name == "aiApertureSize":
                self._aperture_spin.blockSignals(True)
                self._aperture_spin.setValue(float(value))
                self._aperture_spin.blockSignals(False)
                self._set_status("Aperture: {:.4f}".format(float(value)))
            elif attr_name == "focalLength":
                self._focal_spin.blockSignals(True)
                self._focal_spin.setValue(float(value))
                self._focal_spin.blockSignals(False)
                self._set_status("Focal length: {:.1f} mm".format(float(value)))
        except RuntimeError:
            pass

    def closeEvent(self, event):
        if self._core:
            self._core.cleanup_all()
        super(FocusPickerWindow, self).closeEvent(event)


_window_instance = None


def _close_existing_windows():
    app = QtWidgets.QApplication.instance()
    if app is None:
        return
    for widget in list(app.topLevelWidgets()):
        try:
            if (widget.objectName() == "RFX_FocusPickerWindow" or
                    widget.__class__.__name__ == "FocusPickerWindow"):
                widget.close()
                widget.deleteLater()
        except Exception:
            pass


def launch():
    global _window_instance
    _close_existing_windows()
    parent = _maya_main_window()
    _window_instance = FocusPickerWindow(parent=parent)
    _window_instance.show()
    _window_instance.raise_()
    _window_instance.activateWindow()
    try:
        from rfx_ui_scale import attach_screen_watcher

        def _after_rescale(scale, window=_window_instance):
            try:
                window._cam_combo.setFixedHeight(int(round(26.0 * scale)))
            except RuntimeError:
                pass

        attach_screen_watcher(
            _window_instance,
            scale_provider=_focuspicker_ui_scale,
            scale_window=True,
            on_rescaled=_after_rescale,
        )
    except Exception:
        pass
