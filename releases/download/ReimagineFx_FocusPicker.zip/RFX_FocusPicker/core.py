"""
RFX_FocusPicker - core.py
==========================
All Maya-specific logic: attribute reads/writes, ray-casting,
dragger context, and live two-way sync via scriptJob.

Requires: Maya 2020+, OpenMaya API 1.0, Arnold for Maya (MtoA)
"""
from __future__ import annotations

import logging
import sys
import traceback

import maya.cmds       as cmds
import maya.OpenMaya   as om
import maya.OpenMayaUI as omui

log = logging.getLogger(__name__)
if not log.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("[%(name)s] %(levelname)s: %(message)s"))
    log.addHandler(_h)
log.setLevel(logging.INFO)

CONTEXT_NAME = "RFX_FocusPickCtx"

_DEFAULT_CAMS = frozenset({
    "front", "side", "top",
    "frontShape", "sideShape", "topShape",
})

_A_DOF_AI    = "aiEnableDOF"
_A_DOF_NAT   = "depthOfField"
_A_FOCUS_AI  = "aiFocusDistance"
_A_FOCUS_NAT = "focusDistance"
_A_APERTURE  = "aiApertureSize"

_state = {
    "camera_shape"    : None,
    "camera_transform": None,
    "pick_callback"   : None,
    "sync_jobs"       : [],
    "sync_callback"   : None,
    "_writing"        : False,
}


def set_active_camera(transform, shape):
    _state["camera_transform"] = transform
    _state["camera_shape"]     = shape
    _reinstall_sync_jobs(shape)


def get_all_cameras():
    results = []
    for shape in cmds.ls(type="camera") or []:
        if shape in _DEFAULT_CAMS:
            continue
        parents = cmds.listRelatives(shape, parent=True, fullPath=False) or []
        if parents:
            results.append((parents[0], shape))
    results.sort(key=lambda t: t[0].lower())
    return results


def switch_viewport_to_camera(camera_transform):
    try:
        panel = cmds.getPanel(withFocus=True)
        if cmds.getPanel(typeOf=panel) != "modelPanel":
            panels = cmds.getPanel(type="modelPanel") or []
            if not panels:
                return
            panel = panels[0]
        cmds.modelEditor(panel, edit=True, camera=camera_transform)
    except Exception:
        log.exception("Could not switch viewport to '%s'.", camera_transform)


def _attr(camera_shape, name):
    return camera_shape + "." + name


def attr_exists(camera_shape, name):
    return cmds.objExists(_attr(camera_shape, name))


def safe_get(camera_shape, attr_name, default=0.0):
    full = _attr(camera_shape, attr_name)
    if cmds.objExists(full):
        try:
            return float(cmds.getAttr(full))
        except Exception:
            pass
    return default


def safe_set(camera_shape, attr_name, value, undo_label="RFX_FP_set"):
    full = _attr(camera_shape, attr_name)
    if not cmds.objExists(full):
        return False
    _state["_writing"] = True
    cmds.undoInfo(openChunk=True, chunkName=undo_label)
    try:
        cmds.setAttr(full, value)
    except RuntimeError:
        log.exception("setAttr failed for '%s'.", full)
        return False
    finally:
        cmds.undoInfo(closeChunk=True)
        _state["_writing"] = False
    return True


def install_sync_callback(callback):
    """
    Register callback(attr_name, value) fired when Maya changes
    a DOF attribute externally (Arnold tab, Channel Box, etc.).
    """
    _state["sync_callback"] = callback
    cam = _state["camera_shape"]
    if cam:
        _reinstall_sync_jobs(cam)


def remove_sync_callback():
    _state["sync_callback"] = None
    _kill_sync_jobs()


def _kill_sync_jobs():
    for jid in list(_state["sync_jobs"]):
        try:
            if cmds.scriptJob(exists=jid):
                cmds.scriptJob(kill=jid, force=True)
        except Exception:
            pass
    _state["sync_jobs"] = []


def _reinstall_sync_jobs(camera_shape):
    _kill_sync_jobs()
    if not camera_shape or not _state["sync_callback"]:
        return

    # (attr on camera, canonical name forwarded to UI callback)
    watch = [
        (_A_DOF_AI,    _A_DOF_AI),
        (_A_DOF_NAT,   _A_DOF_AI),
        (_A_FOCUS_AI,  _A_FOCUS_AI),
        (_A_FOCUS_NAT, _A_FOCUS_AI),
        (_A_APERTURE,  _A_APERTURE),
    ]

    mod = sys.modules[__name__].__name__

    for attr_name, canonical in watch:
        full = _attr(camera_shape, attr_name)
        if not cmds.objExists(full):
            continue
        try:
            cmd = (
                "import {m}; {m}._on_attr_change"
                "('{cam}', '{attr}', '{canon}')"
            ).format(m=mod, cam=camera_shape,
                     attr=attr_name, canon=canonical)
            jid = cmds.scriptJob(attributeChange=[full, cmd])
            _state["sync_jobs"].append(jid)
        except Exception:
            log.exception("scriptJob failed for %s", full)


def _on_attr_change(camera_shape, attr_name, canonical_name):
    """Called by scriptJob when a watched attribute changes externally."""
    if _state["_writing"]:
        return
    cb = _state["sync_callback"]
    if not callable(cb):
        return
    try:
        val = cmds.getAttr(_attr(camera_shape, attr_name))
        cb(canonical_name, val)
    except Exception:
        log.exception("_on_attr_change failed for %s.%s",
                      camera_shape, attr_name)


def _intersect_scene(screen_x, screen_y):
    view = omui.M3dView.active3dView()
    ray_origin    = om.MPoint()
    ray_direction = om.MVector()
    view.viewToWorld(int(screen_x), int(screen_y), ray_origin, ray_direction)

    ray_o = om.MFloatPoint(ray_origin.x,    ray_origin.y,    ray_origin.z)
    ray_d = om.MFloatVector(ray_direction.x, ray_direction.y, ray_direction.z)

    closest_dist = float("inf")
    hit_found    = False

    dag_iter = om.MItDag(om.MItDag.kDepthFirst, om.MFn.kMesh)
    while not dag_iter.isDone():
        dag_path = om.MDagPath()
        dag_iter.getPath(dag_path)

        if om.MFnDagNode(dag_path).isIntermediateObject():
            dag_iter.next()
            continue

        try:
            mesh_fn = om.MFnMesh(dag_path)
        except RuntimeError:
            dag_iter.next()
            continue

        hit_pt         = om.MFloatPoint()
        hit_param_util = om.MScriptUtil(0.0)
        hit_face_util  = om.MScriptUtil(0)

        hit = mesh_fn.closestIntersection(
            ray_o, ray_d,
            None, None, False,
            om.MSpace.kWorld, 99999, False, None,
            hit_pt,
            hit_param_util.asFloatPtr(),
            hit_face_util.asIntPtr(),
            None, None, None,
        )

        if hit:
            dist = om.MPoint(hit_pt.x, hit_pt.y, hit_pt.z).distanceTo(ray_origin)
            if dist < closest_dist:
                closest_dist = dist
                hit_found    = True

        dag_iter.next()

    return closest_dist if hit_found else None


def apply_focus_distance(camera_shape, distance):
    if safe_set(camera_shape, _A_FOCUS_AI, distance, "RFX_FP_pick_focus"):
        attr_used = _A_FOCUS_AI
    elif safe_set(camera_shape, _A_FOCUS_NAT, distance, "RFX_FP_pick_focus"):
        attr_used = _A_FOCUS_NAT
    else:
        cmds.warning(
            "RFX_FocusPicker: no focus attribute on '" + camera_shape + "'.")
        return
    _inview_msg(attr_used + ": {:.4f}".format(distance))
    log.info("%s -> %.6f", attr_used, distance)


def _inview_msg(text):
    try:
        cmds.inViewMessage(amg="RFX | " + text, pos="topCenter",
                           fade=True, fadeOutTime=3000)
    except Exception:
        pass


def cleanup_dragger():
    try:
        cmds.setToolTo("selectSuperContext")
    except Exception:
        pass
    if cmds.draggerContext(CONTEXT_NAME, exists=True):
        try:
            cmds.deleteUI(CONTEXT_NAME)
        except Exception:
            pass
    _state["pick_callback"] = None


def cleanup_all():
    """Full cleanup -- dragger + all scriptJobs. Call on window close."""
    cleanup_dragger()
    _kill_sync_jobs()


def on_pick_release():
    try:
        anchor = cmds.draggerContext(CONTEXT_NAME, q=True, anchorPoint=True)
        dist   = _intersect_scene(anchor[0], anchor[1])
        cam    = _state["camera_shape"]

        if dist is None:
            cmds.warning("RFX_FocusPicker: No surface hit -- click on an object.")
            return
        if not cam:
            cmds.warning("RFX_FocusPicker: No camera selected.")
            return

        apply_focus_distance(cam, dist)

        cb = _state.get("pick_callback")
        if callable(cb):
            cb(dist)

    except Exception:
        cmds.warning("RFX_FocusPicker error:\n" + traceback.format_exc())
    finally:
        cleanup_dragger()


def on_pick_cancel():
    """
    Called by draggerContext finalize when the user presses Escape.
    Resets the tool cleanly without setting any focus distance.
    """
    cleanup_dragger()
    log.info("Pick cancelled by user.")


def start_pick(camera_shape, result_callback=None):
    _state["camera_shape"]  = camera_shape
    _state["pick_callback"] = result_callback
    cleanup_dragger()

    mod = sys.modules[__name__].__name__
    cmds.draggerContext(
        CONTEXT_NAME,
        releaseCommand="import " + mod + "; " + mod + ".on_pick_release()",
        finalize="import " + mod + "; " + mod + ".on_pick_cancel()",
        cursor="crossHair",
        drawString="Click surface or press Esc to cancel",
    )
    cmds.setToolTo(CONTEXT_NAME)
